import Foundation
import CoreBluetooth
import AppKit
import CoreImage

// MARK: - Constants & Protocol Types

public enum InstaxConstants {
    public static let serviceUUID = CBUUID(string: "70954782-2d83-473d-9e5f-81e1d02d5273")
    public static let writeCharUUID = CBUUID(string: "70954783-2d83-473d-9e5f-81e1d02d5273")
    public static let notifyCharUUID = CBUUID(string: "70954784-2d83-473d-9e5f-81e1d02d5273")

    public static let defaultDeviceName = "INSTAX-"
    public static let squareWidth = 800
    public static let squareHeight = 800
    public static let maxJpegBytes = 60 * 1024
    public static let defaultChunkSize = 1808
}

public enum InstaxLogger {
    public static var onLog: ((String) -> Void)?

    public static func log(_ msg: String) {
        onLog?(msg)
    }
}

public struct InstaxSID: Equatable, Hashable, CustomStringConvertible {
    public let hi: UInt8
    public let lo: UInt8

    public init(_ hi: UInt8, _ lo: UInt8) {
        self.hi = hi
        self.lo = lo
    }

    public static let supportFunctionAndVersionInfo = InstaxSID(0, 0)
    public static let deviceInfoService             = InstaxSID(0, 1)
    public static let supportFunctionInfo           = InstaxSID(0, 2)
    public static let shutDown                      = InstaxSID(1, 0)
    public static let reset                         = InstaxSID(1, 1)
    public static let autoSleepSettings             = InstaxSID(1, 2)
    public static let bleConnect                    = InstaxSID(1, 3)
    public static let printImageDownloadStart       = InstaxSID(16, 0)
    public static let printImageDownloadData        = InstaxSID(16, 1)
    public static let printImageDownloadEnd         = InstaxSID(16, 2)
    public static let printImageDownloadCancel      = InstaxSID(16, 3)
    public static let printImage                    = InstaxSID(16, 128)
    public static let rejectFilmCover               = InstaxSID(16, 129)
    public static let ledPatternSettings            = InstaxSID(48, 1)

    public var name: String {
        switch (hi, lo) {
        case (0, 0): return "SupportFunctionAndVersionInfo"
        case (0, 1): return "DeviceInfoService"
        case (0, 2): return "SupportFunctionInfo"
        case (1, 0): return "ShutDown"
        case (1, 1): return "Reset"
        case (1, 2): return "AutoSleepSettings"
        case (1, 3): return "BLEConnect"
        case (16, 0): return "PrintImageDownloadStart"
        case (16, 1): return "PrintImageDownloadData"
        case (16, 2): return "PrintImageDownloadEnd"
        case (16, 3): return "PrintImageDownloadCancel"
        case (16, 128): return "PrintImage"
        case (16, 129): return "RejectFilmCover"
        case (48, 1): return "LedPatternSettings"
        default: return "SID(\(hi),\(lo))"
        }
    }

    public var description: String {
        name
    }
}

public enum InstaxFitMode: String, CaseIterable, Identifiable {
    case crop = "crop"
    case fit = "fit"
    case stretch = "stretch"

    public var id: String { rawValue }

    public var title: String {
        switch self {
        case .crop: return "Fill Square (Crop)"
        case .fit: return "Fit Entire Image"
        case .stretch: return "Stretch"
        }
    }
}

public enum InstaxPrintMode: String, CaseIterable, Identifiable {
    case none = "none"
    case rich = "rich"
    case natural = "natural"

    public var id: String { rawValue }

    public var title: String {
        switch self {
        case .none: return "Standard / Neutral (No Profile)"
        case .rich: return "instax-Rich Mode (Vibrant Pop)"
        case .natural: return "instax-Natural Mode (Classic 3D-LUT)"
        }
    }

    public var optionByte: UInt8 {
        switch self {
        case .none: return 0x00
        case .rich: return 0x00
        case .natural: return 0x08
        }
    }
}

public enum InstaxFilterPreset: String, CaseIterable, Identifiable {
    case none = "none"
    case monochrome = "monochrome"
    case sepia = "sepia"
    case vintageWarm = "vintage"
    case coolFade = "cool"
    case vivid = "vivid"
    case solarize = "solarize"
    case aerochrome = "aerochrome"
    case crossProcess = "cross_process"
    case duotoneCyan = "duotone_cyan"
    case splitTone = "split_tone"
    case dither = "dither"
    case chromaticAberration = "chromatic"
    case crtScanlines = "crt_scanlines"
    case pixelSort = "pixel_sort"
    case posterize = "posterize"
    case edgeDetect = "edge_detect"
    case threshold = "threshold"
    case emboss = "emboss"

    public var id: String { rawValue }

    public var title: String {
        switch self {
        case .none: return "Original"
        case .monochrome: return "B&W Mono"
        case .sepia: return "Warm Sepia"
        case .vintageWarm: return "Vintage Film"
        case .coolFade: return "Cool Fade"
        case .vivid: return "Vivid Pop"
        case .solarize: return "Solarisation (Sabattier)"
        case .aerochrome: return "False-Colour Infrared"
        case .crossProcess: return "Cross-Processing (X-Pro)"
        case .duotoneCyan: return "Duotone Cyanotype"
        case .splitTone: return "Split-Toning (Amber/Teal)"
        case .dither: return "1-Bit Dithering (Bayer)"
        case .chromaticAberration: return "Chromatic Aberration"
        case .crtScanlines: return "CRT Scanlines"
        case .pixelSort: return "Pixel Sorting (Glitch)"
        case .posterize: return "Posterisation (4-Tone)"
        case .edgeDetect: return "Sobel Edge Detection"
        case .threshold: return "Binarised Stencil"
        case .emboss: return "Embossing (Bas-Relief)"
        }
    }
}

public struct InstaxFilmPresetDefinition: Identifiable, Hashable {
    public let id: String
    public let title: String
    public let category: String
    public let printMode: InstaxPrintMode
    public let filter: InstaxFilterPreset
    public let brightness: Double
    public let contrast: Double
    public let saturation: Double
    public let warmth: Double
    public let vignette: Double
    public let lightLeak: String
    public let leakPlacement: String
    public let leakIntensity: Double
    public let filmGrain: Double
    public let analogWear: Double
    public let showVintageDate: Bool
    public let vintageDateColor: String
    public let vintageDatePlacement: String

    public init(
        id: String,
        title: String,
        category: String,
        printMode: InstaxPrintMode,
        filter: InstaxFilterPreset,
        brightness: Double,
        contrast: Double,
        saturation: Double,
        warmth: Double,
        vignette: Double,
        lightLeak: String,
        leakPlacement: String,
        leakIntensity: Double,
        filmGrain: Double,
        analogWear: Double,
        showVintageDate: Bool,
        vintageDateColor: String,
        vintageDatePlacement: String
    ) {
        self.id = id
        self.title = title
        self.category = category
        self.printMode = printMode
        self.filter = filter
        self.brightness = brightness
        self.contrast = contrast
        self.saturation = saturation
        self.warmth = warmth
        self.vignette = vignette
        self.lightLeak = lightLeak
        self.leakPlacement = leakPlacement
        self.leakIntensity = leakIntensity
        self.filmGrain = filmGrain
        self.analogWear = analogWear
        self.showVintageDate = showVintageDate
        self.vintageDateColor = vintageDateColor
        self.vintageDatePlacement = vintageDatePlacement
    }
}

public struct InstaxFilmCatalog {
    public static let presets: [InstaxFilmPresetDefinition] = [
        // Default / Base Clean Image
        InstaxFilmPresetDefinition(
            id: "default",
            title: "Default / Base (No Effects)",
            category: "Base",
            printMode: .none,
            filter: .none,
            brightness: 0.0,
            contrast: 1.0,
            saturation: 1.0,
            warmth: 0.0,
            vignette: 0.0,
            lightLeak: "none",
            leakPlacement: "auto",
            leakIntensity: 0.70,
            filmGrain: 0.0,
            analogWear: 0.0,
            showVintageDate: false,
            vintageDateColor: "amber",
            vintageDatePlacement: "bottomRight"
        ),
        // Polaroid Emulations
        InstaxFilmPresetDefinition(
            id: "polaroid_sx70",
            title: "Polaroid SX-70 (1972 Warm Chemistry)",
            category: "Polaroid Film",
            printMode: .natural,
            filter: .vintageWarm,
            brightness: 0.04,
            contrast: 0.92,
            saturation: 1.10,
            warmth: 0.35,
            vignette: 0.30,
            lightLeak: "sunburst",
            leakPlacement: "topRight",
            leakIntensity: 0.35,
            filmGrain: 0.25,
            analogWear: 0.10,
            showVintageDate: false,
            vintageDateColor: "amber",
            vintageDatePlacement: "bottomRight"
        ),
        InstaxFilmPresetDefinition(
            id: "polaroid_600",
            title: "Polaroid 600 (Classic 80s/90s Pop)",
            category: "Polaroid Film",
            printMode: .rich,
            filter: .none,
            brightness: 0.02,
            contrast: 1.20,
            saturation: 1.25,
            warmth: 0.15,
            vignette: 0.45,
            lightLeak: "burn",
            leakPlacement: "left",
            leakIntensity: 0.40,
            filmGrain: 0.35,
            analogWear: 0.15,
            showVintageDate: false,
            vintageDateColor: "amber",
            vintageDatePlacement: "bottomRight"
        ),
        InstaxFilmPresetDefinition(
            id: "polaroid_itype",
            title: "Polaroid I-Type / Modern Color",
            category: "Polaroid Film",
            printMode: .rich,
            filter: .none,
            brightness: 0.00,
            contrast: 1.10,
            saturation: 1.15,
            warmth: 0.05,
            vignette: 0.20,
            lightLeak: "none",
            leakPlacement: "auto",
            leakIntensity: 0.70,
            filmGrain: 0.15,
            analogWear: 0.00,
            showVintageDate: false,
            vintageDateColor: "amber",
            vintageDatePlacement: "bottomRight"
        ),
        InstaxFilmPresetDefinition(
            id: "polaroid_spectra",
            title: "Polaroid Spectra / Image System",
            category: "Polaroid Film",
            printMode: .natural,
            filter: .none,
            brightness: 0.03,
            contrast: 1.05,
            saturation: 1.10,
            warmth: 0.25,
            vignette: 0.35,
            lightLeak: "sunset",
            leakPlacement: "right",
            leakIntensity: 0.30,
            filmGrain: 0.20,
            analogWear: 0.05,
            showVintageDate: false,
            vintageDateColor: "amber",
            vintageDatePlacement: "bottomRight"
        ),
        // Vintage & Nostalgia Eras
        InstaxFilmPresetDefinition(
            id: "vintage_70s",
            title: "1970s Golden Vintage",
            category: "Vintage Eras",
            printMode: .natural,
            filter: .vintageWarm,
            brightness: 0.06,
            contrast: 0.88,
            saturation: 0.90,
            warmth: 0.55,
            vignette: 0.50,
            lightLeak: "sunburst",
            leakPlacement: "topRight",
            leakIntensity: 0.60,
            filmGrain: 0.45,
            analogWear: 0.30,
            showVintageDate: false,
            vintageDateColor: "amber",
            vintageDatePlacement: "bottomRight"
        ),
        InstaxFilmPresetDefinition(
            id: "retro_80s",
            title: "1980s Retro Flash Pop",
            category: "Vintage Eras",
            printMode: .rich,
            filter: .vivid,
            brightness: 0.05,
            contrast: 1.30,
            saturation: 1.40,
            warmth: -0.10,
            vignette: 0.40,
            lightLeak: "rainbow",
            leakPlacement: "diagonal",
            leakIntensity: 0.50,
            filmGrain: 0.40,
            analogWear: 0.15,
            showVintageDate: true,
            vintageDateColor: "red",
            vintageDatePlacement: "bottomRight"
        ),
        InstaxFilmPresetDefinition(
            id: "pns_90s",
            title: "1990s Point & Shoot / Disposable",
            category: "Vintage Eras",
            printMode: .rich,
            filter: .none,
            brightness: 0.02,
            contrast: 1.18,
            saturation: 1.15,
            warmth: 0.15,
            vignette: 0.55,
            lightLeak: "burn",
            leakPlacement: "right",
            leakIntensity: 0.35,
            filmGrain: 0.35,
            analogWear: 0.10,
            showVintageDate: true,
            vintageDateColor: "amber",
            vintageDatePlacement: "bottomRight"
        ),
        InstaxFilmPresetDefinition(
            id: "mono_silver",
            title: "1960s Monochrome Silver Halide",
            category: "Vintage Eras",
            printMode: .natural,
            filter: .monochrome,
            brightness: 0.00,
            contrast: 1.35,
            saturation: 0.00,
            warmth: 0.00,
            vignette: 0.40,
            lightLeak: "none",
            leakPlacement: "auto",
            leakIntensity: 0.70,
            filmGrain: 0.60,
            analogWear: 0.20,
            showVintageDate: false,
            vintageDateColor: "white",
            vintageDatePlacement: "bottomRight"
        ),
        // Instax Film Profiles
        InstaxFilmPresetDefinition(
            id: "instax_rich",
            title: "🌈 instax-Rich (Vibrant High Contrast)",
            category: "Instax Profiles",
            printMode: .rich,
            filter: .none,
            brightness: 0.00,
            contrast: 1.00,
            saturation: 1.00,
            warmth: 0.00,
            vignette: 0.00,
            lightLeak: "none",
            leakPlacement: "auto",
            leakIntensity: 0.70,
            filmGrain: 0.00,
            analogWear: 0.00,
            showVintageDate: false,
            vintageDateColor: "amber",
            vintageDatePlacement: "bottomRight"
        ),
        InstaxFilmPresetDefinition(
            id: "instax_natural",
            title: "📷 instax-Natural (3D-LUT Fuji Emulation)",
            category: "Instax Profiles",
            printMode: .natural,
            filter: .none,
            brightness: 0.00,
            contrast: 1.00,
            saturation: 1.00,
            warmth: 0.00,
            vignette: 0.00,
            lightLeak: "none",
            leakPlacement: "auto",
            leakIntensity: 0.70,
            filmGrain: 0.00,
            analogWear: 0.00,
            showVintageDate: false,
            vintageDateColor: "amber",
            vintageDatePlacement: "bottomRight"
        ),
        InstaxFilmPresetDefinition(
            id: "instax_mono",
            title: "Instax Monochrome (B&W Street Film)",
            category: "Instax Profiles",
            printMode: .rich,
            filter: .monochrome,
            brightness: 0.00,
            contrast: 1.15,
            saturation: 0.00,
            warmth: 0.00,
            vignette: 0.15,
            lightLeak: "none",
            leakPlacement: "auto",
            leakIntensity: 0.70,
            filmGrain: 0.25,
            analogWear: 0.00,
            showVintageDate: false,
            vintageDateColor: "amber",
            vintageDatePlacement: "bottomRight"
        ),
        InstaxFilmPresetDefinition(
            id: "instax_sepia",
            title: "Instax Warm Sepia (Nostalgic Tea Wash)",
            category: "Instax Profiles",
            printMode: .natural,
            filter: .sepia,
            brightness: 0.02,
            contrast: 1.05,
            saturation: 0.70,
            warmth: 0.40,
            vignette: 0.25,
            lightLeak: "none",
            leakPlacement: "auto",
            leakIntensity: 0.70,
            filmGrain: 0.20,
            analogWear: 0.05,
            showVintageDate: false,
            vintageDateColor: "amber",
            vintageDatePlacement: "bottomRight"
        )
    ]
}

public enum InstaxCollageLayout: String, CaseIterable, Identifiable {
    case single = "single"
    case split2V = "split2V"
    case split2H = "split2H"
    case split3Hero = "split3Hero"
    case split3V = "split3V"
    case split3H = "split3H"
    case grid4 = "grid4"
    case strips4V = "strips4V"
    case grid6 = "grid6"
    case grid8 = "grid8"
    case grid9 = "grid9"

    public var id: String { rawValue }

    public var title: String {
        switch self {
        case .single: return "Single Photo"
        case .split2V: return "2-Split (Left / Right)"
        case .split2H: return "2-Split (Top / Bottom)"
        case .split3Hero: return "3-Split (Hero Left + 2 Stacked)"
        case .split3V: return "3-Stripes (Vertical WIDE)"
        case .split3H: return "3-Split (Hero Top + 2 Bottom)"
        case .grid4: return "4-Grid (2 × 2)"
        case .strips4V: return "4-Stripes (Photo Booth WIDE)"
        case .grid6: return "6-Grid (3 × 2 WIDE)"
        case .grid8: return "8-Grid (4 × 2 WIDE)"
        case .grid9: return "9-Grid (3 × 3)"
        }
    }

    public var requiredPhotos: Int {
        switch self {
        case .single: return 1
        case .split2V, .split2H: return 2
        case .split3Hero, .split3V, .split3H: return 3
        case .grid4, .strips4V: return 4
        case .grid6: return 6
        case .grid8: return 8
        case .grid9: return 9
        }
    }

    public var icon: String {
        switch self {
        case .single: return "square"
        case .split2V: return "rectangle.split.2x1"
        case .split2H: return "rectangle.split.1x2"
        case .split3Hero: return "rectangle.split.2x2"
        case .split3V: return "rectangle.split.3x1"
        case .split3H: return "rectangle.split.1x2"
        case .grid4: return "square.grid.2x2"
        case .strips4V: return "rectangle.split.3x1"
        case .grid6: return "square.grid.3x2"
        case .grid8: return "square.grid.4x2"
        case .grid9: return "square.grid.3x3"
        }
    }

    public var shortTitle: String {
        switch self {
        case .single: return "Single"
        case .split2V: return "2-Split (V)"
        case .split2H: return "2-Split (H)"
        case .split3Hero: return "3-Split (Hero)"
        case .split3V: return "3-Stripes"
        case .split3H: return "3-Split (Top)"
        case .grid4: return "4-Grid"
        case .strips4V: return "4-Stripes"
        case .grid6: return "6-Grid"
        case .grid8: return "8-Grid"
        case .grid9: return "9-Grid"
        }
    }
}

public enum InstaxQRPosition: String, CaseIterable, Identifiable {
    case bottomRight = "bottomRight"
    case bottomLeft = "bottomLeft"
    case topRight = "topRight"
    case topLeft = "topLeft"
    case bottomCenter = "bottomCenter"

    public var id: String { rawValue }
    public var title: String {
        switch self {
        case .bottomRight: return "Bottom-Right"
        case .bottomLeft: return "Bottom-Left"
        case .topRight: return "Top-Right"
        case .topLeft: return "Top-Left"
        case .bottomCenter: return "Bottom-Center"
        }
    }
}

public enum InstaxQRSize: String, CaseIterable, Identifiable {
    case small = "small"
    case medium = "medium"
    case large = "large"

    public var id: String { rawValue }
    public var title: String {
        switch self {
        case .small: return "Small"
        case .medium: return "Medium"
        case .large: return "Large"
        }
    }

    public func pixelSize(forTargetWidth w: Int) -> CGFloat {
        switch self {
        case .small: return CGFloat(w) * 0.15
        case .medium: return CGFloat(w) * 0.20
        case .large: return CGFloat(w) * 0.26
        }
    }
}

public enum InstaxQRStyle: String, CaseIterable, Identifiable {
    case frosted = "frosted"
    case solidWhite = "solidWhite"
    case minimal = "minimal"

    public var id: String { rawValue }
    public var title: String {
        switch self {
        case .frosted: return "Translucent Glass"
        case .solidWhite: return "Solid White"
        case .minimal: return "Dark Vignette"
        }
    }
    public var shortTitle: String {
        switch self {
        case .frosted: return "Glass"
        case .solidWhite: return "White"
        case .minimal: return "Dark"
        }
    }
}

public enum InstaxBorderColor: String, CaseIterable, Identifiable {
    case white = "white"
    case black = "black"
    case cream = "cream"
    case pastelPink = "pink"
    case pastelBlue = "blue"

    public var id: String { rawValue }

    public var title: String {
        switch self {
        case .white: return "Classic White"
        case .black: return "Black Film"
        case .cream: return "Warm Cream"
        case .pastelPink: return "Pastel Pink"
        case .pastelBlue: return "Pastel Blue"
        }
    }

    public var nsColor: NSColor {
        switch self {
        case .white: return NSColor(srgbRed: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        case .black: return NSColor(srgbRed: 0.10, green: 0.10, blue: 0.12, alpha: 1.0)
        case .cream: return NSColor(srgbRed: 0.98, green: 0.96, blue: 0.90, alpha: 1.0)
        case .pastelPink: return NSColor(srgbRed: 0.98, green: 0.90, blue: 0.92, alpha: 1.0)
        case .pastelBlue: return NSColor(srgbRed: 0.90, green: 0.94, blue: 0.98, alpha: 1.0)
        }
    }
}

public struct InstaxImageOptions {
    public var fitMode: InstaxFitMode = .crop
    public var backgroundColor: NSColor = NSColor(srgbRed: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
    public var zoom: Double = 1.0
    public var offsetX: Double = 0.0
    public var offsetY: Double = 0.0
    public var rotationDegrees: Int = 0
    public var brightness: Double = 0.0   // [-0.5, 0.5]
    public var contrast: Double = 1.0     // [0.5, 1.8]
    public var saturation: Double = 1.0   // [0.0, 2.0]
    public var printMode: InstaxPrintMode = .none
    public var filter: InstaxFilterPreset = .none
    public var filmPreset: String = "none"
    public var borderColor: InstaxBorderColor = .white
    public var captionText: String = ""
    public var showDateStamp: Bool = false
    public var collageSpacing: Double = 8.0
    public var collageLayout: InstaxCollageLayout = .single

    // Rich QR Code Overlays (Web link, text, phone number, Wi-Fi, location)
    public var qrCodeContent: String = ""
    public var qrCodePosition: InstaxQRPosition = .bottomRight
    public var qrCodeSize: InstaxQRSize = .medium
    public var qrCodeStyle: InstaxQRStyle = .frosted

    public var qrContent: String {
        get { qrCodeContent }
        set { qrCodeContent = newValue }
    }
    public var qrPosition: InstaxQRPosition {
        get { qrCodePosition }
        set { qrCodePosition = newValue }
    }
    public var qrSize: InstaxQRSize {
        get { qrCodeSize }
        set { qrCodeSize = newValue }
    }
    public var qrStyle: InstaxQRStyle {
        get { qrCodeStyle }
        set { qrCodeStyle = newValue }
    }

    // Analog Creative FX (Ported from PolaroidEngine)
    public var warmth: Double = 0.0          // [-1.0, 1.0] Cool Blue to Golden Amber
    public var vignette: Double = 0.0        // [0.0, 1.0] Radial lens falloff
    public var lightLeak: String = "none"    // "none", "burn", "sunburst", "sunset", "rainbow"
    public var leakPlacement: String = "auto" // "auto", "left", "right", "topRight", "topLeft", "bottomLeft", "bottomRight", "diagonal"
    public var leakIntensity: Double = 0.70  // [0.1, 1.0]
    public var filmGrain: Double = 0.0       // [0.0, 1.0] Silver halide crystal noise
    public var analogWear: Double = 0.0      // [0.0, 1.0] Dust, hair fibers, scratches & roller spread
    public var showVintageDate: Bool = false
    public var vintageDateText: String = ""  // Custom or auto "'YY MM DD"
    public var vintageDateColor: String = "amber" // "amber", "red", "green", "white"
    public var vintageDatePlacement: String = "bottomRight" // "bottomRight", "bottomLeft", "topRight", "topLeft"
    public var analogSeed: Int = Int.random(in: 1...1_000_000)

    // Decorative Film Borders & Stickers (100% Royalty-Free)
    public var frameStyle: String = "none" // "none", "classic_white", "obsidian_black", "rainbow_gradient", "sunset_ombre", "sprocket_35mm", "gold_metallic", "rose_gold", "pastel_pop", "postage_stamp", "baroque_filigree", "wedding_corners", "stained_glass", "bokeh_sparkles", "fireworks_celebration", "twin_hearts_garland", "holiday_garland", "botanical_foliage"
    public var sticker: String = "none"
    public var stickerImage: NSImage? = nil
    public var stickerPosition: String = "bottomRight" // "bottomRight", "bottomLeft", "topRight", "topLeft", "center", "bottomCenter", "topCenter", "custom"
    public var stickerScale: Double = 0.25 // [0.10, 0.60]
    public var stickerOpacity: Double = 1.0 // [0.10, 1.0]
    public var stickerRotation: Double = 0.0 // [-45.0, 45.0]
    public var stickerX: Double = 0.65       // [-1.0, 1.0]
    public var stickerY: Double = 0.65       // [-1.0, 1.0]

    // Custom Banner Maker
    public var bannerText: String = ""
    public var bannerStyle: String = "none"  // "none", "ribbon", "calligraphy", "pill", "tag", "stamp", "garland"
    public var bannerIcon: String = "none"   // "none", "heart", "sparkles", "party", "star", "camera", "cake", "flower", "ring"
    public var bannerBgColor: String = "#e11d48"
    public var bannerTextColor: String = "#ffffff"
    public var bannerX: Double = 0.0         // [-1.0, 1.0]
    public var bannerY: Double = 0.68        // [-1.0, 1.0]
    public var bannerScale: Double = 1.0     // [0.3, 2.0]
    public var bannerRotation: Double = 0.0  // [-45.0, 45.0]

    public init() {}
}

public struct PrinterStatus: Codable {
    public var deviceName: String = ""
    public var identifier: String = ""
    public var manufacturer: String = ""
    public var modelNumber: String = ""
    public var firmwareVersion: String = ""
    public var width: Int = InstaxConstants.squareWidth
    public var height: Int = InstaxConstants.squareHeight
    public var chunkSize: Int = InstaxConstants.defaultChunkSize
    public var maxJpegSize: Int = InstaxConstants.maxJpegBytes
    public var supports3DLut: Bool = true
    public var batteryPercent: Int = 0
    public var batteryLevel: Int = 0
    public var isCharging: Bool = false
    public var filmRemaining: Int = 0
    public var isCoverOpen: Bool = false
    public var isBusy: Bool = false
    public var hasError: Bool = false
    public var totalPrints: Int = 0
    public var waitSeconds: Int = 15
    public var resultPrintRequest: UInt8 = 0
    public var printerErrorType: UInt32 = 0

    public var printerErrorDescription: String {
        guard hasError || resultPrintRequest == 0xF0 else { return "None" }
        if (printerErrorType & 0x20) != 0 {
            return "Film Ejection Fault / Mechanical Jam (Error 0x20): The printer was unable to cycle the film sheet. If this is a new pack, ensure the black protective plastic dark slide has ejected and the door is clicked shut."
        }
        if (printerErrorType & 0x10) != 0 {
            return "Film Cover Jammed (Error 0x10): The black protective dark slide is jammed in the ejection slot."
        }
        if (printerErrorType & 0x40) != 0 || isCoverOpen {
            return "Film Door Ajar (Error 0x40): The back film door is open or unlatched."
        }
        if (printerErrorType & 0x08) != 0 {
            return "Battery Charge Fault (Error 0x08): Insufficient power to cycle print motor."
        }
        if (printerErrorType & 0x04) != 0 {
            return "Battery Overheating (Error 0x04): Printer temperature is abnormal."
        }
        if (printerErrorType & 0x01) != 0 || (printerErrorType & 0x02) != 0 {
            return "Battery Fault: Battery cannot deliver necessary current to eject film."
        }
        if resultPrintRequest == 0xF0 {
            return "Print Request Rejected (0xF0): Internal mechanical mechanism halted operation."
        }
        if resultPrintRequest == 0x02 {
            return "No Film Remaining: The film pack is empty (0/10)."
        }
        return "Printer Hardware Error (Type: \(String(format: "0x%02X", printerErrorType)), Status: \(String(format: "0x%02X", resultPrintRequest)))"
    }

    public init() {}
}


// MARK: - Packet Framing

public struct InstaxResponse {
    public let sid: InstaxSID
    public let resultCode: UInt8
    public let payload: Data

    public var isOK: Bool { resultCode == 0 }

    public var resultDescription: String {
        switch resultCode {
        case 0: return "OK"
        case 1: return "PRINTER_BUSY"
        case 2: return "CAMERA_BUSY"
        case 127: return "PENDING_RESPONSE"
        case 128: return "SID_NOT_SUPPORTED"
        case 129: return "PARAMETER_ERROR"
        case 130: return "SEQUENCE_ERROR"
        case 144: return "LOW_POWER_ERROR"
        case 145: return "BATTERY_NO_MOUNT_ERROR"
        case 146: return "BATTERY_OVERHEAT_ERROR"
        case 176: return "COVER_OPEN_ERROR"
        case 177: return "NO_FILM_ERROR"
        case 178: return "NO_PAPER_ERROR"
        case 179: return "IMAGE_ERROR"
        case 180: return "PAPER_JAMMED_ERROR"
        case 181: return "PRINT_FAULT_ERROR"
        case 192: return "MEMORY_FULL_ERROR"
        case 194: return "NOW_PRINTING_ERROR"
        default: return "ERROR_\(resultCode)"
        }
    }
}

public enum InstaxPacket {
    /// Build an outbound packet with `0x41 0x62` ('Ab') header and 1-byte checksum.
    public static func build(sid: InstaxSID, payload: Data = Data()) -> Data {
        let totalLength = UInt16(7 + payload.count)
        var bytes = Data(capacity: Int(totalLength))
        bytes.append(0x41) // 'A'
        bytes.append(0x62) // 'b'
        bytes.append(UInt8((totalLength >> 8) & 0xFF))
        bytes.append(UInt8(totalLength & 0xFF))
        bytes.append(sid.hi)
        bytes.append(sid.lo)
        bytes.append(payload)

        var sum: Int = 0
        for b in bytes {
            sum = (sum + Int(b)) & 0xFF
        }
        let checksum = UInt8((255 - sum) & 0xFF)
        bytes.append(checksum)
        return bytes
    }

    /// Parse a complete inbound packet with `0x61 0x42` ('aB') header.
    public static func parse(_ data: Data) throws -> InstaxResponse {
        guard data.count >= 8 else {
            throw NSError(domain: "InstaxPacket", code: 1, userInfo: [NSLocalizedDescriptionKey: "Response too short (\(data.count) bytes)"])
        }
        let b = [UInt8](data)
        guard b[0] == 0x61 && b[1] == 0x42 else {
            throw NSError(domain: "InstaxPacket", code: 2, userInfo: [NSLocalizedDescriptionKey: "Invalid response header"])
        }
        let expectedLen = (Int(b[2]) << 8) | Int(b[3])
        guard b.count >= expectedLen, expectedLen >= 8 else {
            throw NSError(domain: "InstaxPacket", code: 3, userInfo: [NSLocalizedDescriptionKey: "Incomplete response (\(b.count)/\(expectedLen) bytes)"])
        }
        var sum = 0
        for i in 0..<(expectedLen - 1) {
            sum = (sum + Int(b[i])) & 0xFF
        }
        let expectedChecksum = UInt8((255 - sum) & 0xFF)
        let actualChecksum = b[expectedLen - 1]
        guard expectedChecksum == actualChecksum else {
            throw NSError(domain: "InstaxPacket", code: 4, userInfo: [NSLocalizedDescriptionKey: "Checksum mismatch"])
        }
        let sid = InstaxSID(b[4], b[5])
        let resultCode = b[6]
        let payload = expectedLen > 8 ? Data(b[7..<(expectedLen - 1)]) : Data()
        return InstaxResponse(sid: sid, resultCode: resultCode, payload: payload)
    }
}

// MARK: - 800x800 Square Image Renderer & JPEG Compressor

public enum InstaxImageRenderer {
    /// Extract a normalized, upright CGImage from an NSImage with EXIF orientation transforms applied.
    public static func getNormalizedCGImage(from sourceImage: NSImage) -> CGImage? {
        for rep in sourceImage.representations {
            if let bmp = rep as? NSBitmapImageRep, let cg = bmp.cgImage {
                return cg
            }
        }
        if let cg = sourceImage.cgImage(forProposedRect: nil, context: nil, hints: nil) {
            return cg
        }
        if let tiff = sourceImage.tiffRepresentation,
           let source = CGImageSourceCreateWithData(tiff as CFData, nil),
           let cg = CGImageSourceCreateImageAtIndex(source, 0, [
               kCGImageSourceCreateThumbnailWithTransform: true,
               kCGImageSourceCreateThumbnailFromImageAlways: true
           ] as CFDictionary) {
            return cg
        }
        return nil
    }

    /// Render an NSImage into an 800x800 square image with crop/fit/stretch, zoom, pan, rotation, filters, and color adjustments.
    public static func renderSquareImage(
        from sourceImage: NSImage,
        targetWidth: Int = InstaxConstants.squareWidth,
        targetHeight: Int = InstaxConstants.squareHeight,
        options: InstaxImageOptions = InstaxImageOptions()
    ) -> NSImage? {
        guard let cgSource = getNormalizedCGImage(from: sourceImage) else {
            return nil
        }

        let deg = ((options.rotationDegrees % 360) + 360) % 360
        let isNaturalMode = (options.printMode == .natural)
        let isRichMode = (options.printMode == .rich)
        let hasFilter = (options.filter != .none)
        let needsColorFilter = abs(options.brightness) > 0.001 || abs(options.contrast - 1.0) > 0.001 || abs(options.saturation - 1.0) > 0.001 || isNaturalMode || isRichMode || hasFilter

        let processedCG: CGImage
        if deg != 0 || needsColorFilter {
            var ciImage = CIImage(cgImage: cgSource)
            if deg == 90 {
                ciImage = ciImage.oriented(.right)
            } else if deg == 180 {
                ciImage = ciImage.oriented(.down)
            } else if deg == 270 {
                ciImage = ciImage.oriented(.left)
            }

            // Apply selected artistic filter
            switch options.filter {
            case .monochrome:
                if let mono = CIFilter(name: "CIPhotoEffectMono") {
                    mono.setValue(ciImage, forKey: kCIInputImageKey)
                    if let out = mono.outputImage { ciImage = out }
                }
            case .sepia:
                if let sepia = CIFilter(name: "CISepiaTone") {
                    sepia.setValue(ciImage, forKey: kCIInputImageKey)
                    sepia.setValue(0.85, forKey: kCIInputIntensityKey)
                    if let out = sepia.outputImage { ciImage = out }
                }
            case .vintageWarm:
                if let warm = CIFilter(name: "CIPhotoEffectInstant") {
                    warm.setValue(ciImage, forKey: kCIInputImageKey)
                    if let out = warm.outputImage { ciImage = out }
                }
            case .coolFade:
                if let fade = CIFilter(name: "CIPhotoEffectFade") {
                    fade.setValue(ciImage, forKey: kCIInputImageKey)
                    if let out = fade.outputImage { ciImage = out }
                }
            case .vivid:
                if let chrome = CIFilter(name: "CIPhotoEffectChrome") {
                    chrome.setValue(ciImage, forKey: kCIInputImageKey)
                    if let out = chrome.outputImage { ciImage = out }
                }
            case .none, .solarize, .aerochrome, .crossProcess, .duotoneCyan, .splitTone,
                 .dither, .chromaticAberration, .crtScanlines, .pixelSort,
                 .posterize, .edgeDetect, .threshold, .emboss:
                break
            }

            // In rich mode: punchy saturation (+18%) and subtle contrast pop (+8%)
            // In natural mode: simulate Fujifilm's 3D-LUT analog instant film curve:
            // softer contrast (-4%), subtle warm organic highlights, and gentle shadow roll-off
            let effectiveBrightness = options.brightness + (isNaturalMode ? 0.02 : 0.0)
            let effectiveContrast = options.contrast * (isRichMode ? 1.08 : (isNaturalMode ? 0.96 : 1.0))
            let effectiveSaturation = options.saturation * (isRichMode ? 1.18 : (isNaturalMode ? 0.98 : 1.0))

            if let filter = CIFilter(name: "CIColorControls") {
                filter.setValue(ciImage, forKey: kCIInputImageKey)
                filter.setValue(effectiveBrightness, forKey: kCIInputBrightnessKey)
                filter.setValue(effectiveContrast, forKey: kCIInputContrastKey)
                filter.setValue(effectiveSaturation, forKey: kCIInputSaturationKey)
                if let out = filter.outputImage {
                    ciImage = out
                }
            }

            if isNaturalMode, let tempFilter = CIFilter(name: "CITemperatureAndTint") {
                tempFilter.setValue(ciImage, forKey: kCIInputImageKey)
                tempFilter.setValue(CIVector(x: 6500, y: 0), forKey: "inputNeutral")
                tempFilter.setValue(CIVector(x: 6850, y: 8), forKey: "inputTargetNeutral")
                if let out = tempFilter.outputImage {
                    ciImage = out
                }
            }

            let ciContext = CIContext(options: [.useSoftwareRenderer: true])
            guard let cgOut = ciContext.createCGImage(ciImage, from: ciImage.extent) else {
                return nil
            }
            processedCG = cgOut
        } else {
            processedCG = cgSource
        }

        var filteredCG = processedCG
        let advKey: String? = {
            switch options.filter {
            case .solarize: return "solarize"
            case .aerochrome: return "aerochrome"
            case .crossProcess: return "cross_process"
            case .duotoneCyan: return "duotone_cyan"
            case .splitTone: return "split_tone"
            case .dither: return "dither"
            case .chromaticAberration: return "chromatic"
            case .crtScanlines: return "crt_scanlines"
            case .pixelSort: return "pixel_sort"
            case .posterize: return "posterize"
            case .edgeDetect: return "edge_detect"
            case .threshold: return "threshold"
            case .emboss: return "emboss"
            default: return nil
            }
        }()
        if let key = advKey {
            filteredCG = applyAdvancedPixelFilter(filteredCG, filter: key)
        }

        let srcW = Double(filteredCG.width)
        let srcH = Double(filteredCG.height)
        let dstW = Double(targetWidth)
        let dstH = Double(targetHeight)

        let colorSpace = CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB()
        guard let ctx = CGContext(
            data: nil,
            width: targetWidth,
            height: targetHeight,
            bitsPerComponent: 8,
            bytesPerRow: targetWidth * 4,
            space: colorSpace,
            bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
        ) else {
            return nil
        }

        // Fill background with selected border color
        let fallbackWhite = NSColor(srgbRed: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        let bgRGB = (options.fitMode == .fit ? options.backgroundColor : options.borderColor.nsColor).usingColorSpace(.sRGB) ?? fallbackWhite
        ctx.setFillColor(red: bgRGB.redComponent, green: bgRGB.greenComponent, blue: bgRGB.blueComponent, alpha: 1.0)
        ctx.fill(CGRect(x: 0, y: 0, width: dstW, height: dstH))
        ctx.interpolationQuality = .high

        let zoom = max(0.2, options.zoom)
        var drawRect: CGRect

        switch options.fitMode {
        case .stretch:
            let w = dstW * zoom
            let h = dstH * zoom
            let x = (dstW - w) / 2.0 + options.offsetX * (dstW / 2.0)
            let y = (dstH - h) / 2.0 - options.offsetY * (dstH / 2.0)
            drawRect = CGRect(x: x, y: y, width: w, height: h)

        case .fit:
            let scale = min(dstW / srcW, dstH / srcH) * zoom
            let w = srcW * scale
            let h = srcH * scale
            let x = (dstW - w) / 2.0 + options.offsetX * (dstW / 2.0)
            let y = (dstH - h) / 2.0 - options.offsetY * (dstH / 2.0)
            drawRect = CGRect(x: x, y: y, width: w, height: h)

        case .crop:
            let scale = max(dstW / srcW, dstH / srcH) * zoom
            let w = srcW * scale
            let h = srcH * scale
            let maxDX = max(dstW * 0.25, (w - dstW) / 2.0)
            let maxDY = max(dstH * 0.25, (h - dstH) / 2.0)
            let x = (dstW - w) / 2.0 + options.offsetX * maxDX
            let y = (dstH - h) / 2.0 - options.offsetY * maxDY
            drawRect = CGRect(x: x, y: y, width: w, height: h)
        }

        ctx.draw(filteredCG, in: drawRect)

        // Analog Creative FX Pipeline (Ported from PolaroidEngine)
        let fxRect: CGRect = (options.fitMode == .fit) ? drawRect : CGRect(x: 0, y: 0, width: dstW, height: dstH)
        applyAnalogWarmth(ctx: ctx, rect: fxRect, warmth: options.warmth)
        drawLensVignette(ctx: ctx, rect: fxRect, intensity: options.vignette)
        drawLightLeakEffect(ctx: ctx, rect: fxRect, type: options.lightLeak, placement: options.leakPlacement, intensity: options.leakIntensity, seed: options.analogSeed)
        drawTactileFilmGrain(ctx: ctx, rect: fxRect, intensity: options.filmGrain, seed: options.analogSeed)
        drawAnalogWear(ctx: ctx, rect: fxRect, intensity: options.analogWear, seed: options.analogSeed)
        if options.showVintageDate {
            drawVintageDateStamp(ctx: ctx, rect: fxRect, text: options.vintageDateText, colorName: options.vintageDateColor, placement: options.vintageDatePlacement)
        }

        // Decorative Film Borders & Frames
        drawDecorativeFrame(ctx: ctx, width: dstW, height: dstH, style: options.frameStyle)

        // Custom Banner Maker
        drawCustomBanner(ctx: ctx, width: dstW, height: dstH, options: options)

        // Sticker / Custom Image Overlay
        drawStickerOverlay(ctx: ctx, width: dstW, height: dstH, options: options)

        // Draw optional caption or date stamp on bottom using CoreText (headless-safe)
        if !options.captionText.isEmpty || options.showDateStamp {
            let stampText: String
            if !options.captionText.isEmpty && options.showDateStamp {
                let df = DateFormatter()
                df.dateStyle = .medium
                stampText = "\(options.captionText) • \(df.string(from: Date()))"
            } else if !options.captionText.isEmpty {
                stampText = options.captionText
            } else {
                let df = DateFormatter()
                df.dateStyle = .long
                stampText = df.string(from: Date())
            }

            let ctFont = CTFontCreateWithName("Helvetica-Bold" as CFString, 22.0, nil)
            let whiteCG = CGColor(srgbRed: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
            let ctAttrs: [NSAttributedString.Key: Any] = [
                NSAttributedString.Key(kCTFontAttributeName as String): ctFont,
                NSAttributedString.Key(kCTForegroundColorAttributeName as String): whiteCG
            ]
            let attrStr = NSAttributedString(string: stampText, attributes: ctAttrs)
            let ctLine = CTLineCreateWithAttributedString(attrStr)
            let lineBounds = CTLineGetBoundsWithOptions(ctLine, [])

            // Draw translucent pill behind text for contrast
            let pillRect = CGRect(x: (dstW - lineBounds.width - 24) / 2.0, y: 22, width: lineBounds.width + 24, height: lineBounds.height + 12)
            ctx.setFillColor(red: 0, green: 0, blue: 0, alpha: 0.55)
            let pillPath = CGPath(roundedRect: pillRect, cornerWidth: 8, cornerHeight: 8, transform: nil)
            ctx.addPath(pillPath)
            ctx.fillPath()

            ctx.saveGState()
            ctx.textMatrix = .identity
            ctx.textPosition = CGPoint(x: (dstW - lineBounds.width) / 2.0, y: 28 - lineBounds.origin.y * 0.5)
            CTLineDraw(ctLine, ctx)
            ctx.restoreGState()
        }

        // Draw optional QR Code (Rich QR / Web link / Secret text / Contact)
        let trimmedQR = options.qrCodeContent.trimmingCharacters(in: .whitespacesAndNewlines)
        if !trimmedQR.isEmpty {
            let qrSize = options.qrCodeSize.pixelSize(forTargetWidth: targetWidth)
            if let qrImage = generateQRCode(from: trimmedQR, size: qrSize) {
                let margin: CGFloat = max(18.0, dstW * 0.035)
                let qrRect: CGRect
                switch options.qrCodePosition {
                case .bottomRight:
                    qrRect = CGRect(x: dstW - qrSize - margin, y: margin, width: qrSize, height: qrSize)
                case .bottomLeft:
                    qrRect = CGRect(x: margin, y: margin, width: qrSize, height: qrSize)
                case .topRight:
                    qrRect = CGRect(x: dstW - qrSize - margin, y: dstH - qrSize - margin, width: qrSize, height: qrSize)
                case .topLeft:
                    qrRect = CGRect(x: margin, y: dstH - qrSize - margin, width: qrSize, height: qrSize)
                case .bottomCenter:
                    qrRect = CGRect(x: (dstW - qrSize) / 2.0, y: margin, width: qrSize, height: qrSize)
                }

                let badgePadding: CGFloat = 8.0
                let badgeRect = qrRect.insetBy(dx: -badgePadding, dy: -badgePadding)
                switch options.qrCodeStyle {
                case .frosted:
                    ctx.setFillColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 0.92)
                    let path = CGPath(roundedRect: badgeRect, cornerWidth: 10, cornerHeight: 10, transform: nil)
                    ctx.addPath(path)
                    ctx.fillPath()
                    ctx.setStrokeColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.2)
                    ctx.setLineWidth(1.5)
                    ctx.addPath(path)
                    ctx.strokePath()
                case .solidWhite:
                    ctx.setFillColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
                    let path = CGPath(roundedRect: badgeRect, cornerWidth: 8, cornerHeight: 8, transform: nil)
                    ctx.addPath(path)
                    ctx.fillPath()
                case .minimal:
                    ctx.setFillColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.65)
                    let path = CGPath(roundedRect: badgeRect, cornerWidth: 8, cornerHeight: 8, transform: nil)
                    ctx.addPath(path)
                    ctx.fillPath()
                }

                ctx.draw(qrImage, in: qrRect)
            }
        }

        guard let outCG = ctx.makeImage() else {
            return nil
        }
        let rep = NSBitmapImageRep(cgImage: outCG)
        rep.size = NSSize(width: targetWidth, height: targetHeight)
        let outImg = NSImage(size: NSSize(width: targetWidth, height: targetHeight))
        outImg.addRepresentation(rep)
        return outImg
    }

    public static func applyAdvancedPixelFilter(_ cgImage: CGImage, filter: String) -> CGImage {
        let width = cgImage.width
        let height = cgImage.height
        let bytesPerPixel = 4
        let bytesPerRow = width * bytesPerPixel
        let bitsPerComponent = 8
        let colorSpace = CGColorSpaceCreateDeviceRGB()

        guard let context = CGContext(
            data: nil,
            width: width,
            height: height,
            bitsPerComponent: bitsPerComponent,
            bytesPerRow: bytesPerRow,
            space: colorSpace,
            bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue | CGBitmapInfo.byteOrder32Big.rawValue
        ) else {
            return cgImage
        }

        let rect = CGRect(x: 0, y: 0, width: width, height: height)
        context.draw(cgImage, in: rect)

        guard let data = context.data else {
            return cgImage
        }

        let buffer = data.bindMemory(to: UInt8.self, capacity: width * height * 4)

        switch filter {
        case "solarize":
            let orig = UnsafeMutablePointer<UInt8>.allocate(capacity: width * height * 4)
            orig.initialize(from: buffer, count: width * height * 4)
            for py in 0..<height {
                for px in 0..<width {
                    let idx = (py * width + px) * 4
                    for c in 0..<3 {
                        let v = Int(orig[idx + c])
                        orig[idx + c] = UInt8(clamping: v < 128 ? (255 - 2 * v) : (2 * (v - 128)))
                    }
                }
            }
            for py in 1..<(height - 1) {
                for px in 1..<(width - 1) {
                    let idx = (py * width + px) * 4
                    let leftIdx = (py * width + (px - 1)) * 4
                    let upIdx = ((py - 1) * width + px) * 4
                    let diff = abs(Int(orig[idx]) - Int(orig[leftIdx])) + abs(Int(orig[idx + 1]) - Int(orig[leftIdx + 1])) +
                               abs(Int(orig[idx]) - Int(orig[upIdx])) + abs(Int(orig[idx + 1]) - Int(orig[upIdx + 1]))
                    if diff > 120 {
                        buffer[idx] = UInt8(clamping: Int(orig[idx]) + 75)
                        buffer[idx + 1] = UInt8(clamping: Int(orig[idx + 1]) + 75)
                        buffer[idx + 2] = UInt8(clamping: Int(orig[idx + 2]) + 75)
                    } else {
                        buffer[idx] = orig[idx]
                        buffer[idx + 1] = orig[idx + 1]
                        buffer[idx + 2] = orig[idx + 2]
                    }
                }
            }
            orig.deallocate()

        case "aerochrome":
            for i in stride(from: 0, to: width * height * 4, by: 4) {
                let r = Double(buffer[i])
                let g = Double(buffer[i + 1])
                let b = Double(buffer[i + 2])
                if g > b * 0.95 && g > 40.0 && (g >= r * 0.75 || (r > b && g > b * 1.1)) {
                    let greenExcess = max(0.0, g - max(r, b) * 0.5)
                    buffer[i] = UInt8(clamping: Int(g * 1.35 + greenExcess * 0.8 + 25.0))
                    buffer[i + 1] = UInt8(clamping: max(0, Int(b * 0.35 + r * 0.15)))
                    buffer[i + 2] = UInt8(clamping: Int(g * 0.65 + b * 0.55 + 20.0))
                } else if b > r * 1.15 && b > g {
                    buffer[i] = UInt8(clamping: max(0, Int(r * 0.55)))
                    buffer[i + 1] = UInt8(clamping: Int(g * 0.95 + b * 0.25))
                    buffer[i + 2] = UInt8(clamping: Int(b * 1.25))
                } else {
                    buffer[i] = UInt8(clamping: Int(r * 1.15 + g * 0.1))
                    buffer[i + 1] = UInt8(clamping: Int(g * 0.85))
                    buffer[i + 2] = UInt8(clamping: Int(b * 0.9 + 10.0))
                }
            }

        case "cross_process":
            for i in stride(from: 0, to: width * height * 4, by: 4) {
                var r = Double(buffer[i]) / 255.0
                var g = Double(buffer[i + 1]) / 255.0
                var b = Double(buffer[i + 2]) / 255.0

                r = r < 0.5 ? 2.0 * r * r : 1.0 - 2.0 * (1.0 - r) * (1.0 - r)
                r = min(1.0, max(0.0, r * 1.12))

                if g < 0.5 {
                    g = min(1.0, pow(g, 0.82) * 1.10)
                } else {
                    g = min(1.0, pow(g, 1.05))
                }

                b = min(1.0, max(0.0, pow(b, 1.28) * 0.92))

                buffer[i] = UInt8(clamping: Int(r * 255.0))
                buffer[i + 1] = UInt8(clamping: Int(g * 255.0))
                buffer[i + 2] = UInt8(clamping: Int(b * 255.0))
            }

        case "duotone_cyan":
            for i in stride(from: 0, to: width * height * 4, by: 4) {
                let lum = (0.299 * Double(buffer[i]) + 0.587 * Double(buffer[i + 1]) + 0.114 * Double(buffer[i + 2])) / 255.0
                buffer[i] = UInt8(clamping: Int(11.0 + lum * (250.0 - 11.0)))
                buffer[i + 1] = UInt8(clamping: Int(37.0 + lum * (248.0 - 37.0)))
                buffer[i + 2] = UInt8(clamping: Int(69.0 + lum * (245.0 - 69.0)))
            }

        case "split_tone":
            for i in stride(from: 0, to: width * height * 4, by: 4) {
                let lum = (0.299 * Double(buffer[i]) + 0.587 * Double(buffer[i + 1]) + 0.114 * Double(buffer[i + 2])) / 255.0
                let t = lum < 0.5 ? 2.0 * lum * lum : 1.0 - 2.0 * (1.0 - lum) * (1.0 - lum)
                buffer[i] = UInt8(clamping: Int(0.0 * (1.0 - t) + 255.0 * t))
                buffer[i + 1] = UInt8(clamping: Int(72.0 * (1.0 - t) + 183.0 * t))
                buffer[i + 2] = UInt8(clamping: Int(92.0 * (1.0 - t) + 77.0 * t))
            }

        case "dither":
            let bayer: [[Double]] = [
                [0.0, 8.0, 2.0, 10.0],
                [12.0, 4.0, 14.0, 6.0],
                [3.0, 11.0, 1.0, 9.0],
                [15.0, 7.0, 13.0, 5.0]
            ]
            for py in 0..<height {
                for px in 0..<width {
                    let idx = (py * width + px) * 4
                    let lum = 0.299 * Double(buffer[idx]) + 0.587 * Double(buffer[idx + 1]) + 0.114 * Double(buffer[idx + 2])
                    let threshold = (bayer[py % 4][px % 4] + 0.5) * (255.0 / 16.0)
                    let val: UInt8 = lum >= threshold ? 255 : 0
                    buffer[idx] = val
                    buffer[idx + 1] = val
                    buffer[idx + 2] = val
                }
            }

        case "chromatic":
            let orig = UnsafeMutablePointer<UInt8>.allocate(capacity: width * height * 4)
            orig.initialize(from: buffer, count: width * height * 4)
            let shift = 5
            for py in 0..<height {
                for px in 0..<width {
                    let idx = (py * width + px) * 4
                    let rxPos = max(0, min(width - 1, px - shift))
                    let bxPos = max(0, min(width - 1, px + shift))
                    buffer[idx] = orig[(py * width + rxPos) * 4]
                    buffer[idx + 1] = orig[idx + 1]
                    buffer[idx + 2] = orig[(py * width + bxPos) * 4 + 2]
                }
            }
            orig.deallocate()

        case "crt_scanlines":
            for py in 0..<height {
                let isScanline = (py % 2 == 1)
                let scanDim = isScanline ? 0.68 : 1.0
                for px in 0..<width {
                    let idx = (py * width + px) * 4
                    let phosphor = px % 3
                    let pr = scanDim * (phosphor == 0 ? 1.25 : 0.85)
                    let pg = scanDim * (phosphor == 1 ? 1.25 : 0.85)
                    let pb = scanDim * (phosphor == 2 ? 1.25 : 0.85)
                    buffer[idx] = UInt8(clamping: Int(Double(buffer[idx]) * pr))
                    buffer[idx + 1] = UInt8(clamping: Int(Double(buffer[idx + 1]) * pg))
                    buffer[idx + 2] = UInt8(clamping: Int(Double(buffer[idx + 2]) * pb))
                }
            }

        case "pixel_sort":
            for py in 0..<height {
                var px = 0
                while px < width {
                    var idx = (py * width + px) * 4
                    var lum = (0.299 * Double(buffer[idx]) + 0.587 * Double(buffer[idx + 1]) + 0.114 * Double(buffer[idx + 2])) / 255.0
                    if lum >= 0.28 && lum <= 0.80 {
                        let startX = px
                        var span: [(r: UInt8, g: UInt8, b: UInt8, a: UInt8, lum: Double)] = []
                        while px < width {
                            idx = (py * width + px) * 4
                            lum = (0.299 * Double(buffer[idx]) + 0.587 * Double(buffer[idx + 1]) + 0.114 * Double(buffer[idx + 2])) / 255.0
                            if lum < 0.28 || lum > 0.80 { break }
                            span.append((buffer[idx], buffer[idx + 1], buffer[idx + 2], buffer[idx + 3], lum))
                            px += 1
                        }
                        if span.count > 2 {
                            span.sort { $0.lum < $1.lum }
                            for k in 0..<span.count {
                                let widx = (py * width + (startX + k)) * 4
                                buffer[widx] = span[k].r
                                buffer[widx + 1] = span[k].g
                                buffer[widx + 2] = span[k].b
                                buffer[widx + 3] = span[k].a
                            }
                        }
                    } else {
                        px += 1
                    }
                }
            }

        case "posterize":
            for i in stride(from: 0, to: width * height * 4, by: 4) {
                buffer[i] = UInt8(clamping: Int(round(Double(buffer[i]) / 85.0) * 85.0))
                buffer[i + 1] = UInt8(clamping: Int(round(Double(buffer[i + 1]) / 85.0) * 85.0))
                buffer[i + 2] = UInt8(clamping: Int(round(Double(buffer[i + 2]) / 85.0) * 85.0))
            }

        case "edge_detect":
            let orig = UnsafeMutablePointer<UInt8>.allocate(capacity: width * height * 4)
            orig.initialize(from: buffer, count: width * height * 4)
            let lum = UnsafeMutablePointer<Double>.allocate(capacity: width * height)
            for i in 0..<(width * height) {
                lum[i] = 0.299 * Double(orig[i * 4]) + 0.587 * Double(orig[i * 4 + 1]) + 0.114 * Double(orig[i * 4 + 2])
            }
            for py in 1..<(height - 1) {
                for px in 1..<(width - 1) {
                    let idx = (py * width + px) * 4
                    let gx = -1.0 * lum[(py - 1) * width + (px - 1)] + 1.0 * lum[(py - 1) * width + (px + 1)] -
                             2.0 * lum[py * width + (px - 1)]       + 2.0 * lum[py * width + (px + 1)] -
                             1.0 * lum[(py + 1) * width + (px - 1)] + 1.0 * lum[(py + 1) * width + (px + 1)]
                    let gy = -1.0 * lum[(py - 1) * width + (px - 1)] - 2.0 * lum[(py - 1) * width + px] - 1.0 * lum[(py - 1) * width + (px + 1)] +
                              1.0 * lum[(py + 1) * width + (px - 1)] + 2.0 * lum[(py + 1) * width + px] + 1.0 * lum[(py + 1) * width + (px + 1)]
                    let mag = min(255.0, Double(Darwin.hypot(gx, gy)))
                    let edgeNorm = mag / 255.0
                    buffer[idx] = UInt8(clamping: Int(8.0 * (1.0 - edgeNorm) + mag * 0.15))
                    buffer[idx + 1] = UInt8(clamping: Int(13.0 * (1.0 - edgeNorm) + mag * 0.90))
                    buffer[idx + 2] = UInt8(clamping: Int(26.0 * (1.0 - edgeNorm) + mag * 1.0))
                }
            }
            orig.deallocate()
            lum.deallocate()

        case "threshold":
            for i in stride(from: 0, to: width * height * 4, by: 4) {
                let l = 0.299 * Double(buffer[i]) + 0.587 * Double(buffer[i + 1]) + 0.114 * Double(buffer[i + 2])
                let val: UInt8 = l >= 128.0 ? 255 : 0
                buffer[i] = val
                buffer[i + 1] = val
                buffer[i + 2] = val
            }

        case "emboss":
            let orig = UnsafeMutablePointer<UInt8>.allocate(capacity: width * height * 4)
            orig.initialize(from: buffer, count: width * height * 4)
            let lum = UnsafeMutablePointer<Double>.allocate(capacity: width * height)
            for i in 0..<(width * height) {
                lum[i] = 0.299 * Double(orig[i * 4]) + 0.587 * Double(orig[i * 4 + 1]) + 0.114 * Double(orig[i * 4 + 2])
            }
            for py in 1..<(height - 1) {
                for px in 1..<(width - 1) {
                    let idx = (py * width + px) * 4
                    let val = -2.0 * lum[(py - 1) * width + (px - 1)] - 1.0 * lum[(py - 1) * width + px] -
                              1.0 * lum[py * width + (px - 1)]       + 1.0 * lum[py * width + px]       + 1.0 * lum[py * width + (px + 1)] +
                              1.0 * lum[(py + 1) * width + px]       + 2.0 * lum[(py + 1) * width + (px + 1)]
                    let clamped = UInt8(clamping: Int(val + 128.0))
                    buffer[idx] = clamped
                    buffer[idx + 1] = clamped
                    buffer[idx + 2] = clamped
                }
            }
            orig.deallocate()
            lum.deallocate()

        default:
            break
        }

        return context.makeImage() ?? cgImage
    }

    // MARK: - Analog Creative FX Methods

    public static func applyAnalogWarmth(ctx: CGContext, rect: CGRect, warmth: Double) {
        guard abs(warmth) >= 0.01 else { return }
        ctx.saveGState()
        ctx.clip(to: rect)
        ctx.setBlendMode(.softLight)
        if warmth > 0 {
            let alpha = min(1.0, warmth * 0.65)
            ctx.setFillColor(red: 1.0, green: 175.0 / 255.0, blue: 45.0 / 255.0, alpha: CGFloat(alpha))
            ctx.fill(rect)
        } else {
            let alpha = min(1.0, (-warmth) * 0.65)
            ctx.setFillColor(red: 45.0 / 255.0, green: 135.0 / 255.0, blue: 1.0, alpha: CGFloat(alpha))
            ctx.fill(rect)
        }
        if warmth > 0.4 {
            ctx.setBlendMode(.multiply)
            let alpha = (warmth - 0.4) * 0.30
            ctx.setFillColor(red: 1.0, green: 240.0 / 255.0, blue: 210.0 / 255.0, alpha: CGFloat(alpha))
            ctx.fill(rect)
        }
        ctx.restoreGState()
    }

    public static func drawLensVignette(ctx: CGContext, rect: CGRect, intensity: Double) {
        guard intensity > 0.01 else { return }
        ctx.saveGState()
        ctx.clip(to: rect)
        let cx = rect.midX
        let cy = rect.midY
        let maxR = hypot(rect.width, rect.height) / 2.0
        let colorSpace = CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB()
        let colors: [CGColor] = [
            CGColor(srgbRed: 0, green: 0, blue: 0, alpha: 0),
            CGColor(srgbRed: 0, green: 0, blue: 0, alpha: CGFloat(intensity * 0.30)),
            CGColor(srgbRed: 0, green: 0, blue: 0, alpha: CGFloat(intensity * 0.90))
        ]
        let locations: [CGFloat] = [0.0, 0.65, 1.0]
        if let gradient = CGGradient(colorsSpace: colorSpace, colors: colors as CFArray, locations: locations) {
            ctx.drawRadialGradient(gradient, startCenter: CGPoint(x: cx, y: cy), startRadius: maxR * 0.32, endCenter: CGPoint(x: cx, y: cy), endRadius: maxR, options: [.drawsAfterEndLocation])
        }
        ctx.restoreGState()
    }

    public static func drawLightLeakEffect(ctx: CGContext, rect: CGRect, type: String, placement: String, intensity: Double, seed: Int = 12345) {
        guard type != "none" && intensity > 0.01 else { return }
        ctx.saveGState()
        ctx.clip(to: rect)
        ctx.setBlendMode(.screen)
        ctx.setAlpha(CGFloat(min(1.0, intensity)))

        var p = placement
        if p.isEmpty || p == "auto" {
            let placements = ["left", "right", "topRight", "topLeft", "bottomLeft", "bottomRight", "diagonal"]
            if seed == 12345 {
                p = placements.randomElement() ?? "right"
            } else {
                p = placements[abs(seed) % placements.count]
            }
        }

        let c1: CGColor
        let c2: CGColor
        let c3: CGColor
        if type == "sunburst" {
            c1 = CGColor(srgbRed: 1.0, green: 250.0 / 255.0, blue: 215.0 / 255.0, alpha: 1.0)
            c2 = CGColor(srgbRed: 1.0, green: 175.0 / 255.0, blue: 45.0 / 255.0, alpha: 0.75)
            c3 = CGColor(srgbRed: 240.0 / 255.0, green: 70.0 / 255.0, blue: 38.0 / 255.0, alpha: 0.30)
        } else if type == "sunset" {
            c1 = CGColor(srgbRed: 1.0, green: 115.0 / 255.0, blue: 45.0 / 255.0, alpha: 0.95)
            c2 = CGColor(srgbRed: 1.0, green: 190.0 / 255.0, blue: 75.0 / 255.0, alpha: 0.60)
            c3 = CGColor(srgbRed: 190.0 / 255.0, green: 38.0 / 255.0, blue: 115.0 / 255.0, alpha: 0.25)
        } else {
            c1 = CGColor(srgbRed: 1.0, green: 45.0 / 255.0, blue: 15.0 / 255.0, alpha: 0.95)
            c2 = CGColor(srgbRed: 1.0, green: 140.0 / 255.0, blue: 30.0 / 255.0, alpha: 0.65)
            c3 = CGColor(srgbRed: 205.0 / 255.0, green: 20.0 / 255.0, blue: 90.0 / 255.0, alpha: 0.25)
        }

        let colorSpace = CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB()
        let leakColors: [CGColor] = [c1, c2, c3, CGColor(srgbRed: 0, green: 0, blue: 0, alpha: 0)]
        let leakLocations: [CGFloat] = [0.0, 0.35, 0.70, 1.0]

        if let grad = CGGradient(colorsSpace: colorSpace, colors: leakColors as CFArray, locations: leakLocations) {
            let x = rect.origin.x
            let y = rect.origin.y
            let w = rect.width
            let h = rect.height

            switch p {
            case "left":
                ctx.drawLinearGradient(grad, start: CGPoint(x: x, y: y + h * 0.5), end: CGPoint(x: x + w * 0.45, y: y + h * 0.5), options: [])
            case "right":
                ctx.drawLinearGradient(grad, start: CGPoint(x: x + w, y: y + h * 0.5), end: CGPoint(x: x + w - w * 0.45, y: y + h * 0.5), options: [])
            case "topRight":
                let center = CGPoint(x: x + w, y: rect.maxY)
                ctx.drawRadialGradient(grad, startCenter: center, startRadius: 0, endCenter: center, endRadius: w * 0.85, options: [])
            case "topLeft":
                let center = CGPoint(x: x, y: rect.maxY)
                ctx.drawRadialGradient(grad, startCenter: center, startRadius: 0, endCenter: center, endRadius: w * 0.85, options: [])
            case "bottomLeft":
                ctx.drawLinearGradient(grad, start: CGPoint(x: x, y: rect.minY), end: CGPoint(x: x + w * 0.5 + 60, y: rect.minY + h * 0.5 + 60), options: [])
            case "bottomRight":
                let center = CGPoint(x: x + w, y: rect.minY)
                ctx.drawRadialGradient(grad, startCenter: center, startRadius: 0, endCenter: center, endRadius: w * 0.85, options: [])
            case "diagonal":
                ctx.drawLinearGradient(grad, start: CGPoint(x: x, y: rect.maxY), end: CGPoint(x: x + w, y: rect.minY), options: [])
            default:
                ctx.drawLinearGradient(grad, start: CGPoint(x: x, y: y + h * 0.5), end: CGPoint(x: x + w * 0.45, y: y + h * 0.5), options: [])
            }
        }

        if type == "rainbow" {
            let rainbowColors: [CGColor] = [
                CGColor(srgbRed: 1.0, green: 64.0 / 255.0, blue: 64.0 / 255.0, alpha: 0.65),
                CGColor(srgbRed: 1.0, green: 153.0 / 255.0, blue: 38.0 / 255.0, alpha: 0.65),
                CGColor(srgbRed: 1.0, green: 230.0 / 255.0, blue: 51.0 / 255.0, alpha: 0.65),
                CGColor(srgbRed: 64.0 / 255.0, green: 217.0 / 255.0, blue: 115.0 / 255.0, alpha: 0.65),
                CGColor(srgbRed: 51.0 / 255.0, green: 153.0 / 255.0, blue: 242.0 / 255.0, alpha: 0.65),
                CGColor(srgbRed: 166.0 / 255.0, green: 77.0 / 255.0, blue: 217.0 / 255.0, alpha: 0.65)
            ]
            let stripeW = rect.width * 0.08
            for i in 0..<6 {
                ctx.setFillColor(rainbowColors[i])
                let stripeRect = CGRect(x: rect.origin.x + rect.width - CGFloat(6 - i) * stripeW, y: rect.origin.y, width: stripeW * 1.4, height: rect.height)
                ctx.fill(stripeRect)
            }
        }

        ctx.restoreGState()
    }

    public static func drawTactileFilmGrain(ctx: CGContext, rect: CGRect, intensity: Double, seed: Int = 12345) {
        guard intensity > 0.01 else { return }
        let gw = min(320, max(64, Int(rect.width / 2.2)))
        let gh = min(320, max(64, Int(rect.height / 2.2)))

        var s = seed
        var pixelData = [UInt8](repeating: 0, count: gw * gh * 4)
        for i in stride(from: 0, to: pixelData.count, by: 4) {
            s = (s &* 9301 &+ 49297) % 233280
            let val = UInt8((s * 256) / 233280)
            pixelData[i] = val
            pixelData[i + 1] = val
            pixelData[i + 2] = val
            pixelData[i + 3] = 255
        }

        let colorSpace = CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB()
        guard let provider = CGDataProvider(data: Data(pixelData) as CFData),
              let grainCG = CGImage(
                width: gw,
                height: gh,
                bitsPerComponent: 8,
                bitsPerPixel: 32,
                bytesPerRow: gw * 4,
                space: colorSpace,
                bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue),
                provider: provider,
                decode: nil,
                shouldInterpolate: false,
                intent: .defaultIntent
              ) else { return }

        ctx.saveGState()
        ctx.clip(to: rect)
        ctx.setBlendMode(.overlay)
        ctx.setAlpha(CGFloat(min(1.0, intensity * 0.85)))
        ctx.interpolationQuality = .none
        ctx.draw(grainCG, in: rect)
        ctx.restoreGState()
    }

    public static func drawAnalogWear(ctx: CGContext, rect: CGRect, intensity: Double, seed: Int = 54321) {
        guard intensity > 0.01 else { return }
        ctx.saveGState()
        ctx.clip(to: rect)

        var s = seed
        func rng() -> Double {
            s = (s &* 9301 &+ 49297) % 233280
            return Double(s) / 233280.0
        }

        let dustCount = 10 + Int(intensity * 32.0)
        for _ in 0..<dustCount {
            let rx = rect.origin.x + CGFloat(rng()) * rect.width
            let ry = rect.origin.y + CGFloat(rng()) * rect.height
            let isWhite = rng() < 0.33
            let alpha = (0.20 + rng() * 0.40) * min(1.0, intensity * 1.2)

            let strokeColor = isWhite ? CGColor(srgbRed: 242/255, green: 242/255, blue: 245/255, alpha: CGFloat(alpha))
                                      : CGColor(srgbRed: 38/255, green: 30/255, blue: 25/255, alpha: CGFloat(alpha * 0.85))

            let type = Int(rng() * 3)
            if type == 0 {
                let len = CGFloat(5.0 + rng() * 14.0)
                let angle = CGFloat(rng() * 2.0 * .pi)
                let curve = CGFloat(-4.0 + rng() * 8.0)

                ctx.setLineWidth(CGFloat(0.8 + rng() * 0.6))
                ctx.setLineCap(.round)
                ctx.setStrokeColor(strokeColor)

                let path = CGMutablePath()
                path.move(to: CGPoint(x: rx, y: ry))
                let ctrlX = rx + cos(angle) * (len * 0.5) + sin(angle) * curve
                let ctrlY = ry + sin(angle) * (len * 0.5) - cos(angle) * curve
                let endX = rx + cos(angle) * len
                let endY = ry + sin(angle) * len
                path.addQuadCurve(to: CGPoint(x: endX, y: endY), control: CGPoint(x: ctrlX, y: ctrlY))
                ctx.addPath(path)
                ctx.strokePath()
            } else if type == 1 {
                let len = CGFloat(8.0 + rng() * 26.0)
                let angle = CGFloat(rng() * .pi)
                ctx.setLineWidth(0.7)
                ctx.setStrokeColor(strokeColor)
                ctx.strokeLineSegments(between: [
                    CGPoint(x: rx, y: ry),
                    CGPoint(x: rx + cos(angle) * len, y: ry + sin(angle) * len)
                ])
            } else {
                let r = CGFloat(0.8 + rng() * 1.5)
                ctx.setFillColor(strokeColor)
                ctx.fillEllipse(in: CGRect(x: rx - r, y: ry - r, width: r * 2, height: r * 2))
            }
        }

        if intensity > 0.12 {
            ctx.setBlendMode(.screen)
            let podAtBottom = Int(rng() * 2) == 0
            let gradH = rect.height * CGFloat(0.08 + intensity * 0.12)
            let colorSpace = CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB()
            let c1 = CGColor(srgbRed: 1.0, green: 191/255, blue: 115/255, alpha: CGFloat(0.26 * intensity))
            let c2 = CGColor(srgbRed: 230/255, green: 153/255, blue: 76/255, alpha: CGFloat(0.10 * intensity))
            let c3 = CGColor(srgbRed: 0, green: 0, blue: 0, alpha: 0)

            if let grad = CGGradient(colorsSpace: colorSpace, colors: [c1, c2, c3] as CFArray, locations: [0.0, 0.4, 1.0]) {
                if podAtBottom {
                    ctx.drawLinearGradient(grad, start: CGPoint(x: rect.origin.x, y: rect.minY), end: CGPoint(x: rect.origin.x, y: rect.minY + gradH), options: [])
                } else {
                    ctx.drawLinearGradient(grad, start: CGPoint(x: rect.origin.x, y: rect.maxY), end: CGPoint(x: rect.origin.x, y: rect.maxY - gradH), options: [])
                }
            }
        }

        ctx.restoreGState()
    }

    public static func drawVintageDateStamp(ctx: CGContext, rect: CGRect, text: String, colorName: String, placement: String) {
        var stamp = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if stamp.isEmpty {
            let df = DateFormatter()
            df.dateFormat = "''yy MM dd"
            stamp = df.string(from: Date())
        }

        let textColor: CGColor
        let glowColor: CGColor
        if colorName == "red" {
            textColor = CGColor(srgbRed: 1.0, green: 37/255, blue: 37/255, alpha: 1.0)
            glowColor = CGColor(srgbRed: 1.0, green: 37/255, blue: 37/255, alpha: 0.75)
        } else if colorName == "green" {
            textColor = CGColor(srgbRed: 0.0, green: 230/255, blue: 118/255, alpha: 1.0)
            glowColor = CGColor(srgbRed: 0.0, green: 230/255, blue: 118/255, alpha: 0.75)
        } else if colorName == "white" {
            textColor = CGColor(srgbRed: 245/255, green: 245/255, blue: 247/255, alpha: 1.0)
            glowColor = CGColor(srgbRed: 245/255, green: 245/255, blue: 247/255, alpha: 0.75)
        } else {
            textColor = CGColor(srgbRed: 1.0, green: 140/255, blue: 0.0, alpha: 1.0)
            glowColor = CGColor(srgbRed: 1.0, green: 140/255, blue: 0.0, alpha: 0.75)
        }

        let fontSize = max(14.0, rect.width * 0.042)
        let ctFont = CTFontCreateWithName("Courier-Bold" as CFString, fontSize, nil)
        let attrs: [NSAttributedString.Key: Any] = [
            NSAttributedString.Key(kCTFontAttributeName as String): ctFont,
            NSAttributedString.Key(kCTForegroundColorAttributeName as String): textColor
        ]
        let attrStr = NSAttributedString(string: stamp, attributes: attrs)
        let ctLine = CTLineCreateWithAttributedString(attrStr)
        let lineBounds = CTLineGetBoundsWithOptions(ctLine, [])

        let padX = rect.width * 0.04
        let padY = rect.height * 0.04

        var stampX: CGFloat
        var stampY: CGFloat

        switch placement {
        case "bottomLeft":
            stampX = rect.minX + padX
            stampY = rect.minY + padY
        case "topRight":
            stampX = rect.maxX - lineBounds.width - padX
            stampY = rect.maxY - padY - fontSize
        case "topLeft":
            stampX = rect.minX + padX
            stampY = rect.maxY - padY - fontSize
        default:
            stampX = rect.maxX - lineBounds.width - padX
            stampY = rect.minY + padY
        }

        ctx.saveGState()
        ctx.setShadow(offset: .zero, blur: 6.0, color: glowColor)
        ctx.textMatrix = .identity
        ctx.textPosition = CGPoint(x: stampX, y: stampY)
        CTLineDraw(ctLine, ctx)
        ctx.restoreGState()
    }

    /// Generate a crisp vector QR code using macOS CoreImage CIQRCodeGenerator.
    public static func generateQRCode(from text: String, size: CGFloat) -> CGImage? {
        guard let data = text.data(using: .utf8) else { return nil }
        guard let filter = CIFilter(name: "CIQRCodeGenerator") else { return nil }
        filter.setValue(data, forKey: "inputMessage")
        filter.setValue("M", forKey: "inputCorrectionLevel")
        guard let outputCI = filter.outputImage else { return nil }

        let scale = size / outputCI.extent.size.width
        let transformed = outputCI.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        let ciContext = CIContext(options: [.useSoftwareRenderer: true])
        return ciContext.createCGImage(transformed, from: transformed.extent.integral)
    }

    // MARK: - Decorative Frames & Stickers Engine

    public static let stickerMap: [String: String] = [
        "party_popper": "🎉",
        "birthday_cake": "🎂",
        "sparkles": "✨",
        "cheers": "🥂",
        "balloon": "🎈",
        "gift": "🎁",
        "camera": "📸",
        "airplane": "✈️",
        "palm_tree": "🌴",
        "tent": "⛺️",
        "mountain": "⛰️",
        "sun": "☀️",
        "wave": "🌊",
        "heart": "❤️",
        "sparkle_heart": "💖",
        "two_hearts": "💕",
        "love_letter": "💌",
        "rose": "🌹",
        "bouquet": "💐",
        "paw": "🐾",
        "puppy": "🐶",
        "kitten": "🐱",
        "cherry_blossom": "🌸",
        "coffee": "☕️",
        "four_leaf_clover": "🍀",
        "cassette": "📼",
        "sunglasses": "🕶️",
        "peace": "✌️",
        "lightning": "⚡️",
        "music": "🎵",
        "fire": "🔥",
        // Hand-Drawn Love & Romance Doodles
        "love_script": "💖",
        "i_love_you": "❤️",
        "forever_heart": "♾️",
        "sketchy_heart": "✏️",
        "winged_heart": "🪽",
        "love_envelope": "💌",
        "shining_heart": "🌟",
        "heart_balloons": "🎈",
        "heart_arrow": "💘",
        "heart_hands": "🫶",
        "looping_heart": "➰",
        // Celebrations & Holidays Doodles
        "birthday_cake_doodle": "🎂",
        "birthday_bunting": "🚩",
        "happy_holidays_gold": "✨",
        "season_greetings": "🌿",
        "xmas_tree": "🎄",
        "holly_berries": "🍒",
        "christmas_stockings": "🧦",
        "halloween_ghost": "👻",
        "jack_o_lantern": "🎃",
        "flying_bats": "🦇",
        "summer_flipflops": "🩴",
        "seashells": "🐚",
        "cherry_blossoms": "🌸",
        "mimosa": "🌾"
    ]

    public static func drawDecorativeFrame(ctx: CGContext, width: CGFloat, height: CGFloat, style: String) {
        guard !style.isEmpty && style != "none" else { return }
        ctx.saveGState()

        if style == "classic_white" {
            let borderX = round(width * 0.05)
            let borderTop = round(height * 0.05)
            let borderBottom = round(height * 0.14)
            ctx.setFillColor(red: 248/255.0, green: 250/255.0, blue: 252/255.0, alpha: 1.0)
            ctx.fill([
                CGRect(x: 0, y: height - borderTop, width: width, height: borderTop),
                CGRect(x: 0, y: 0, width: borderX, height: height),
                CGRect(x: width - borderX, y: 0, width: borderX, height: height),
                CGRect(x: 0, y: 0, width: width, height: borderBottom)
            ])
            ctx.setStrokeColor(red: 0, green: 0, blue: 0, alpha: 0.12)
            ctx.setLineWidth(1.5)
            ctx.stroke(CGRect(x: borderX, y: borderBottom, width: width - 2 * borderX, height: height - borderTop - borderBottom))
        } else if style == "obsidian_black" {
            let borderX = round(width * 0.05)
            let borderTop = round(height * 0.05)
            let borderBottom = round(height * 0.14)
            ctx.setFillColor(red: 17/255.0, green: 24/255.0, blue: 39/255.0, alpha: 1.0)
            ctx.fill([
                CGRect(x: 0, y: height - borderTop, width: width, height: borderTop),
                CGRect(x: 0, y: 0, width: borderX, height: height),
                CGRect(x: width - borderX, y: 0, width: borderX, height: height),
                CGRect(x: 0, y: 0, width: width, height: borderBottom)
            ])
            ctx.setStrokeColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 0.15)
            ctx.setLineWidth(1.0)
            ctx.stroke(CGRect(x: borderX, y: borderBottom, width: width - 2 * borderX, height: height - borderTop - borderBottom))
        } else if style == "rainbow_gradient" {
            let bw = round(min(width, height) * 0.065)
            let colors: [CGColor] = [
                CGColor(srgbRed: 239/255.0, green: 68/255.0, blue: 68/255.0, alpha: 1.0),
                CGColor(srgbRed: 249/255.0, green: 115/255.0, blue: 22/255.0, alpha: 1.0),
                CGColor(srgbRed: 234/255.0, green: 179/255.0, blue: 8/255.0, alpha: 1.0),
                CGColor(srgbRed: 34/255.0, green: 197/255.0, blue: 94/255.0, alpha: 1.0),
                CGColor(srgbRed: 6/255.0, green: 182/255.0, blue: 212/255.0, alpha: 1.0),
                CGColor(srgbRed: 139/255.0, green: 92/255.0, blue: 246/255.0, alpha: 1.0),
                CGColor(srgbRed: 236/255.0, green: 72/255.0, blue: 153/255.0, alpha: 1.0)
            ]
            let colorSpace = CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB()
            let locations: [CGFloat] = [0.0, 0.18, 0.36, 0.54, 0.72, 0.90, 1.0]
            if let gradient = CGGradient(colorsSpace: colorSpace, colors: colors as CFArray, locations: locations) {
                ctx.saveGState()
                ctx.addRects([
                    CGRect(x: 0, y: height - bw, width: width, height: bw),
                    CGRect(x: 0, y: 0, width: bw, height: height),
                    CGRect(x: width - bw, y: 0, width: bw, height: height),
                    CGRect(x: 0, y: 0, width: width, height: bw)
                ])
                ctx.clip()
                ctx.drawLinearGradient(gradient, start: CGPoint(x: 0, y: 0), end: CGPoint(x: width, y: height), options: [])
                ctx.restoreGState()
            }
            ctx.setStrokeColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 0.35)
            ctx.setLineWidth(1.5)
            ctx.stroke(CGRect(x: bw, y: bw, width: width - 2 * bw, height: height - 2 * bw))
        } else if style == "sunset_ombre" {
            let bw = round(min(width, height) * 0.065)
            let colors: [CGColor] = [
                CGColor(srgbRed: 244/255.0, green: 63/255.0, blue: 94/255.0, alpha: 1.0),
                CGColor(srgbRed: 251/255.0, green: 146/255.0, blue: 60/255.0, alpha: 1.0),
                CGColor(srgbRed: 99/255.0, green: 102/255.0, blue: 241/255.0, alpha: 1.0)
            ]
            let colorSpace = CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB()
            let locations: [CGFloat] = [0.0, 0.5, 1.0]
            if let gradient = CGGradient(colorsSpace: colorSpace, colors: colors as CFArray, locations: locations) {
                ctx.saveGState()
                ctx.addRects([
                    CGRect(x: 0, y: height - bw, width: width, height: bw),
                    CGRect(x: 0, y: 0, width: bw, height: height),
                    CGRect(x: width - bw, y: 0, width: bw, height: height),
                    CGRect(x: 0, y: 0, width: width, height: bw)
                ])
                ctx.clip()
                ctx.drawLinearGradient(gradient, start: CGPoint(x: 0, y: height), end: CGPoint(x: 0, y: 0), options: [])
                ctx.restoreGState()
            }
            ctx.setStrokeColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 0.35)
            ctx.setLineWidth(1.5)
            ctx.stroke(CGRect(x: bw, y: bw, width: width - 2 * bw, height: height - 2 * bw))
        } else if style == "sprocket_35mm" {
            let bw = round(min(width, height) * 0.08)
            ctx.setFillColor(red: 10/255.0, green: 10/255.0, blue: 10/255.0, alpha: 1.0)
            ctx.fill([
                CGRect(x: 0, y: 0, width: bw, height: height),
                CGRect(x: width - bw, y: 0, width: bw, height: height)
            ])
            let holeW = round(bw * 0.45)
            let holeH = round(bw * 0.65)
            let step = holeH + round(bw * 0.4)
            let startY = round(bw * 0.3)
            ctx.setFillColor(red: 229/255.0, green: 231/255.0, blue: 235/255.0, alpha: 1.0)
            var y = startY
            while y + holeH < height {
                let leftPath = CGPath(roundedRect: CGRect(x: (bw - holeW) / 2.0, y: y, width: holeW, height: holeH), cornerWidth: 3, cornerHeight: 3, transform: nil)
                let rightPath = CGPath(roundedRect: CGRect(x: width - bw + (bw - holeW) / 2.0, y: y, width: holeW, height: holeH), cornerWidth: 3, cornerHeight: 3, transform: nil)
                ctx.addPath(leftPath)
                ctx.addPath(rightPath)
                ctx.fillPath()
                y += step
            }
        } else if style == "gold_metallic" {
            let bw = round(min(width, height) * 0.065)
            let colors: [CGColor] = [
                CGColor(srgbRed: 180/255.0, green: 83/255.0, blue: 9/255.0, alpha: 1.0),
                CGColor(srgbRed: 254/255.0, green: 240/255.0, blue: 138/255.0, alpha: 1.0),
                CGColor(srgbRed: 217/255.0, green: 119/255.0, blue: 6/255.0, alpha: 1.0),
                CGColor(srgbRed: 254/255.0, green: 249/255.0, blue: 195/255.0, alpha: 1.0),
                CGColor(srgbRed: 146/255.0, green: 64/255.0, blue: 14/255.0, alpha: 1.0)
            ]
            let colorSpace = CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB()
            let locations: [CGFloat] = [0.0, 0.3, 0.6, 0.85, 1.0]
            if let gradient = CGGradient(colorsSpace: colorSpace, colors: colors as CFArray, locations: locations) {
                ctx.saveGState()
                ctx.addRects([
                    CGRect(x: 0, y: height - bw, width: width, height: bw),
                    CGRect(x: 0, y: 0, width: bw, height: height),
                    CGRect(x: width - bw, y: 0, width: bw, height: height),
                    CGRect(x: 0, y: 0, width: width, height: bw)
                ])
                ctx.clip()
                ctx.drawLinearGradient(gradient, start: CGPoint(x: 0, y: 0), end: CGPoint(x: width, y: height), options: [])
                ctx.restoreGState()
            }
            ctx.setStrokeColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 0.45)
            ctx.setLineWidth(1.5)
            ctx.stroke(CGRect(x: bw, y: bw, width: width - 2 * bw, height: height - 2 * bw))
        } else if style == "rose_gold" {
            let bw = round(min(width, height) * 0.065)
            let colors: [CGColor] = [
                CGColor(srgbRed: 159/255.0, green: 18/255.0, blue: 57/255.0, alpha: 1.0),
                CGColor(srgbRed: 251/255.0, green: 207/255.0, blue: 232/255.0, alpha: 1.0),
                CGColor(srgbRed: 251/255.0, green: 113/255.0, blue: 133/255.0, alpha: 1.0),
                CGColor(srgbRed: 252/255.0, green: 231/255.0, blue: 243/255.0, alpha: 1.0),
                CGColor(srgbRed: 136/255.0, green: 19/255.0, blue: 55/255.0, alpha: 1.0)
            ]
            let colorSpace = CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB()
            let locations: [CGFloat] = [0.0, 0.3, 0.65, 0.9, 1.0]
            if let gradient = CGGradient(colorsSpace: colorSpace, colors: colors as CFArray, locations: locations) {
                ctx.saveGState()
                ctx.addRects([
                    CGRect(x: 0, y: height - bw, width: width, height: bw),
                    CGRect(x: 0, y: 0, width: bw, height: height),
                    CGRect(x: width - bw, y: 0, width: bw, height: height),
                    CGRect(x: 0, y: 0, width: width, height: bw)
                ])
                ctx.clip()
                ctx.drawLinearGradient(gradient, start: CGPoint(x: 0, y: 0), end: CGPoint(x: width, y: height), options: [])
                ctx.restoreGState()
            }
            ctx.setStrokeColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 0.45)
            ctx.setLineWidth(1.5)
            ctx.stroke(CGRect(x: bw, y: bw, width: width - 2 * bw, height: height - 2 * bw))
        } else if style == "pastel_pop" {
            let bw = round(min(width, height) * 0.065)
            ctx.setFillColor(red: 186/255.0, green: 230/255.0, blue: 253/255.0, alpha: 1.0)
            ctx.fill(CGRect(x: 0, y: height - bw, width: width, height: bw))
            ctx.setFillColor(red: 251/255.0, green: 207/255.0, blue: 232/255.0, alpha: 1.0)
            ctx.fill(CGRect(x: 0, y: 0, width: bw, height: height))
            ctx.setFillColor(red: 187/255.0, green: 247/255.0, blue: 208/255.0, alpha: 1.0)
            ctx.fill(CGRect(x: width - bw, y: 0, width: bw, height: height))
            ctx.setFillColor(red: 254/255.0, green: 240/255.0, blue: 138/255.0, alpha: 1.0)
            ctx.fill(CGRect(x: 0, y: 0, width: width, height: bw))
            ctx.setStrokeColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 0.55)
            ctx.setLineWidth(1.5)
            ctx.stroke(CGRect(x: bw, y: bw, width: width - 2 * bw, height: height - 2 * bw))
        } else if style == "postage_stamp" {
            let bw = round(min(width, height) * 0.05)
            ctx.setFillColor(red: 254/255.0, green: 254/255.0, blue: 254/255.0, alpha: 1.0)
            ctx.fill([
                CGRect(x: 0, y: height - bw, width: width, height: bw),
                CGRect(x: 0, y: 0, width: bw, height: height),
                CGRect(x: width - bw, y: 0, width: bw, height: height),
                CGRect(x: 0, y: 0, width: width, height: bw)
            ])
            let r = round(bw * 0.45)
            let d = r * 2.8
            ctx.setFillColor(red: 30/255.0, green: 30/255.0, blue: 30/255.0, alpha: 1.0)
            var x = d / 2.0
            while x < width {
                ctx.fillEllipse(in: CGRect(x: x - r, y: -r, width: 2 * r, height: 2 * r))
                ctx.fillEllipse(in: CGRect(x: x - r, y: height - r, width: 2 * r, height: 2 * r))
                x += d
            }
            var y = d / 2.0
            while y < height {
                ctx.fillEllipse(in: CGRect(x: -r, y: y - r, width: 2 * r, height: 2 * r))
                ctx.fillEllipse(in: CGRect(x: width - r, y: y - r, width: 2 * r, height: 2 * r))
                y += d
            }
        } else if style == "baroque_filigree" {
            // Baroque Filigree Oval & Ornate Corner Scrolls
            let bw = round(min(width, height) * 0.07)
            ctx.setFillColor(red: 253/255.0, green: 242/255.0, blue: 248/255.0, alpha: 0.85)
            ctx.fill([
                CGRect(x: 0, y: height - bw, width: width, height: bw),
                CGRect(x: 0, y: 0, width: bw, height: height),
                CGRect(x: width - bw, y: 0, width: bw, height: height),
                CGRect(x: 0, y: 0, width: width, height: bw)
            ])
            ctx.setStrokeColor(red: 190/255.0, green: 24/255.0, blue: 93/255.0, alpha: 0.8)
            ctx.setLineWidth(2.0)
            ctx.strokeEllipse(in: CGRect(x: bw, y: bw, width: width - 2 * bw, height: height - 2 * bw))
            // Corner flourishes
            func drawCornerFiligree(cx: CGFloat, cy: CGFloat, rot: CGFloat) {
                ctx.saveGState()
                ctx.translateBy(x: cx, y: cy)
                ctx.rotate(by: rot)
                ctx.beginPath()
                ctx.move(to: CGPoint(x: 0, y: 0))
                ctx.addQuadCurve(to: CGPoint(x: 35, y: 35), control: CGPoint(x: 20, y: 0))
                ctx.addQuadCurve(to: CGPoint(x: 0, y: 0), control: CGPoint(x: 0, y: 20))
                ctx.strokePath()
                ctx.strokeEllipse(in: CGRect(x: 14, y: 14, width: 8, height: 8))
                ctx.restoreGState()
            }
            drawCornerFiligree(cx: bw, cy: height - bw, rot: 0)
            drawCornerFiligree(cx: width - bw, cy: height - bw, rot: -.pi / 2.0)
            drawCornerFiligree(cx: width - bw, cy: bw, rot: .pi)
            drawCornerFiligree(cx: bw, cy: bw, rot: .pi / 2.0)

        } else if style == "wedding_corners" {
            // Delicate Wedding Floral Corner Brackets
            let pad = round(min(width, height) * 0.05)
            ctx.setStrokeColor(red: 74/255.0, green: 122/255.0, blue: 95/255.0, alpha: 0.75)
            ctx.setLineWidth(1.8)
            func drawFloralCorner(cx: CGFloat, cy: CGFloat, sx: CGFloat, sy: CGFloat) {
                ctx.saveGState()
                ctx.translateBy(x: cx, y: cy)
                ctx.scaleBy(x: sx, y: sy)
                ctx.beginPath()
                ctx.move(to: CGPoint(x: 0, y: 55))
                ctx.addLine(to: CGPoint(x: 0, y: 12))
                ctx.addQuadCurve(to: CGPoint(x: 12, y: 0), control: CGPoint(x: 0, y: 0))
                ctx.addLine(to: CGPoint(x: 55, y: 0))
                ctx.strokePath()
                // Blossom & leaves
                ctx.setFillColor(red: 251/255.0, green: 113/255.0, blue: 133/255.0, alpha: 0.9)
                ctx.fillEllipse(in: CGRect(x: 6, y: 6, width: 14, height: 14))
                ctx.setFillColor(red: 134/255.0, green: 239/255.0, blue: 172/255.0, alpha: 0.85)
                ctx.fillEllipse(in: CGRect(x: 20, y: 4, width: 8, height: 5))
                ctx.fillEllipse(in: CGRect(x: 4, y: 20, width: 5, height: 8))
                ctx.restoreGState()
            }
            drawFloralCorner(cx: pad, cy: height - pad, sx: 1, sy: -1)
            drawFloralCorner(cx: width - pad, cy: height - pad, sx: -1, sy: -1)
            drawFloralCorner(cx: pad, cy: pad, sx: 1, sy: 1)
            drawFloralCorner(cx: width - pad, cy: pad, sx: -1, sy: 1)

        } else if style == "stained_glass" {
            // Leaded Stained Glass Mosaic Border
            let bw = round(min(width, height) * 0.065)
            let segW = round(min(width, height) * 0.08)
            let gemColors: [CGColor] = [
                CGColor(srgbRed: 239/255.0, green: 68/255.0, blue: 68/255.0, alpha: 0.85),
                CGColor(srgbRed: 59/255.0, green: 130/255.0, blue: 246/255.0, alpha: 0.85),
                CGColor(srgbRed: 234/255.0, green: 179/255.0, blue: 8/255.0, alpha: 0.85),
                CGColor(srgbRed: 34/255.0, green: 197/255.0, blue: 94/255.0, alpha: 0.85),
                CGColor(srgbRed: 168/255.0, green: 85/255.0, blue: 247/255.0, alpha: 0.85)
            ]
            var cIdx = 0
            var x: CGFloat = 0
            while x < width {
                ctx.setFillColor(gemColors[cIdx % gemColors.count])
                ctx.fill(CGRect(x: x, y: height - bw, width: segW, height: bw))
                cIdx += 1
                ctx.setFillColor(gemColors[cIdx % gemColors.count])
                ctx.fill(CGRect(x: x, y: 0, width: segW, height: bw))
                cIdx += 1
                x += segW
            }
            var y: CGFloat = bw
            while y < height - bw {
                ctx.setFillColor(gemColors[cIdx % gemColors.count])
                ctx.fill(CGRect(x: 0, y: y, width: bw, height: segW))
                cIdx += 1
                ctx.setFillColor(gemColors[cIdx % gemColors.count])
                ctx.fill(CGRect(x: width - bw, y: y, width: bw, height: segW))
                cIdx += 1
                y += segW
            }
            ctx.setStrokeColor(red: 24/255.0, green: 24/255.0, blue: 27/255.0, alpha: 1.0)
            ctx.setLineWidth(2.5)
            ctx.stroke(CGRect(x: 0, y: 0, width: width, height: height))
            ctx.stroke(CGRect(x: bw, y: bw, width: width - 2 * bw, height: height - 2 * bw))

        } else if style == "bokeh_sparkles" {
            // Glowing Bokeh & Twinkling Sparkles
            struct Orb { let x: CGFloat; let y: CGFloat; let r: CGFloat; let color: CGColor }
            let orbs: [Orb] = [
                Orb(x: 0.12, y: 0.92, r: 24, color: CGColor(srgbRed: 254/255.0, green: 240/255.0, blue: 138/255.0, alpha: 0.40)),
                Orb(x: 0.28, y: 0.95, r: 18, color: CGColor(srgbRed: 251/255.0, green: 207/255.0, blue: 232/255.0, alpha: 0.35)),
                Orb(x: 0.72, y: 0.93, r: 26, color: CGColor(srgbRed: 221/255.0, green: 214/255.0, blue: 254/255.0, alpha: 0.38)),
                Orb(x: 0.88, y: 0.88, r: 20, color: CGColor(srgbRed: 254/255.0, green: 240/255.0, blue: 138/255.0, alpha: 0.45)),
                Orb(x: 0.05, y: 0.65, r: 16, color: CGColor(srgbRed: 251/255.0, green: 207/255.0, blue: 232/255.0, alpha: 0.30)),
                Orb(x: 0.95, y: 0.58, r: 22, color: CGColor(srgbRed: 254/255.0, green: 240/255.0, blue: 138/255.0, alpha: 0.35)),
                Orb(x: 0.08, y: 0.18, r: 28, color: CGColor(srgbRed: 221/255.0, green: 214/255.0, blue: 254/255.0, alpha: 0.40)),
                Orb(x: 0.22, y: 0.06, r: 18, color: CGColor(srgbRed: 254/255.0, green: 240/255.0, blue: 138/255.0, alpha: 0.38)),
                Orb(x: 0.78, y: 0.08, r: 25, color: CGColor(srgbRed: 251/255.0, green: 207/255.0, blue: 232/255.0, alpha: 0.42)),
                Orb(x: 0.92, y: 0.15, r: 20, color: CGColor(srgbRed: 254/255.0, green: 240/255.0, blue: 138/255.0, alpha: 0.40))
            ]
            for o in orbs {
                ctx.setFillColor(o.color)
                ctx.fillEllipse(in: CGRect(x: o.x * width - o.r, y: o.y * height - o.r, width: o.r * 2, height: o.r * 2))
            }
            func drawStar(sx: CGFloat, sy: CGFloat, rad: CGFloat) {
                ctx.setFillColor(red: 1, green: 1, blue: 1, alpha: 0.9)
                let starPath = CGMutablePath()
                starPath.move(to: CGPoint(x: sx, y: sy - rad))
                starPath.addQuadCurve(to: CGPoint(x: sx + rad, y: sy), control: CGPoint(x: sx, y: sy))
                starPath.addQuadCurve(to: CGPoint(x: sx, y: sy + rad), control: CGPoint(x: sx, y: sy))
                starPath.addQuadCurve(to: CGPoint(x: sx - rad, y: sy), control: CGPoint(x: sx, y: sy))
                starPath.addQuadCurve(to: CGPoint(x: sx, y: sy - rad), control: CGPoint(x: sx, y: sy))
                ctx.addPath(starPath)
                ctx.fillPath()
            }
            drawStar(sx: width * 0.18, sy: height * 0.94, rad: 8)
            drawStar(sx: width * 0.82, sy: height * 0.91, rad: 10)
            drawStar(sx: width * 0.07, sy: height * 0.35, rad: 7)
            drawStar(sx: width * 0.93, sy: height * 0.40, rad: 9)
            drawStar(sx: width * 0.50, sy: height * 0.05, rad: 8)

        } else if style == "fireworks_celebration" {
            // Fireworks Celebration Corner Starbursts
            func drawFirework(cx: CGFloat, cy: CGFloat, colors: [CGColor]) {
                let rays = 12
                for i in 0..<rays {
                    let ang = CGFloat(i) / CGFloat(rays) * .pi * 2.0
                    let len: CGFloat = 35.0 + CGFloat(i % 3) * 15.0
                    let col = colors[i % colors.count]
                    ctx.setStrokeColor(col)
                    ctx.setLineWidth(1.5)
                    ctx.beginPath()
                    ctx.move(to: CGPoint(x: cx, y: cy))
                    ctx.addLine(to: CGPoint(x: cx + cos(ang) * len, y: cy + sin(ang) * len))
                    ctx.strokePath()
                    ctx.setFillColor(col)
                    ctx.fillEllipse(in: CGRect(x: cx + cos(ang) * (len + 4) - 2, y: cy + sin(ang) * (len + 4) - 2, width: 4, height: 4))
                }
                ctx.setFillColor(red: 1, green: 1, blue: 1, alpha: 1)
                ctx.fillEllipse(in: CGRect(x: cx - 3, y: cy - 3, width: 6, height: 6))
            }
            let c1 = [CGColor(srgbRed: 251/255.0, green: 191/255.0, blue: 36/255.0, alpha: 1), CGColor(srgbRed: 248/255.0, green: 113/255.0, blue: 113/255.0, alpha: 1), CGColor(srgbRed: 96/255.0, green: 165/255.0, blue: 250/255.0, alpha: 1)]
            let c2 = [CGColor(srgbRed: 52/255.0, green: 211/255.0, blue: 153/255.0, alpha: 1), CGColor(srgbRed: 251/255.0, green: 191/255.0, blue: 36/255.0, alpha: 1), CGColor(srgbRed: 167/255.0, green: 139/255.0, blue: 250/255.0, alpha: 1)]
            drawFirework(cx: 60, cy: height - 60, colors: c1)
            drawFirework(cx: width - 70, cy: height - 70, colors: c2)
            drawFirework(cx: 80, cy: 80, colors: c2)
            drawFirework(cx: width - 65, cy: 75, colors: c1)

        } else if style == "twin_hearts_garland" {
            // Hanging Twin Hearts Garland Wire
            let garlandY = height - round(height * 0.05)
            ctx.setStrokeColor(red: 1, green: 1, blue: 1, alpha: 0.65)
            ctx.setLineWidth(1.5)
            ctx.beginPath()
            ctx.move(to: CGPoint(x: 20, y: garlandY))
            ctx.addCurve(to: CGPoint(x: width - 20, y: garlandY), control1: CGPoint(x: width * 0.33, y: garlandY - 25), control2: CGPoint(x: width * 0.66, y: garlandY - 25))
            ctx.strokePath()

            let heartCols: [CGColor] = [
                CGColor(srgbRed: 244/255.0, green: 63/255.0, blue: 94/255.0, alpha: 1),
                CGColor(srgbRed: 251/255.0, green: 113/255.0, blue: 133/255.0, alpha: 1),
                CGColor(srgbRed: 253/255.0, green: 164/255.0, blue: 175/255.0, alpha: 1),
                CGColor(srgbRed: 225/255.0, green: 29/255.0, blue: 72/255.0, alpha: 1)
            ]
            let numHearts = 7
            for i in 0..<numHearts {
                let t = CGFloat(i) / CGFloat(numHearts - 1)
                let hx = 20.0 + t * (width - 40.0)
                let strY = garlandY - 4.0 * 25.0 * t * (1.0 - t)
                let dropLen: CGFloat = 14.0 + CGFloat(i % 2) * 10.0
                let hy = strY - dropLen

                ctx.setStrokeColor(red: 1, green: 1, blue: 1, alpha: 0.45)
                ctx.setLineWidth(1.0)
                ctx.beginPath()
                ctx.move(to: CGPoint(x: hx, y: strY))
                ctx.addLine(to: CGPoint(x: hx, y: hy))
                ctx.strokePath()

                ctx.setFillColor(heartCols[i % heartCols.count])
                let hr: CGFloat = 8.0 + CGFloat(i % 2) * 3.0
                let hp = CGMutablePath()
                hp.move(to: CGPoint(x: hx, y: hy - hr * 0.7))
                hp.addCurve(to: CGPoint(x: hx, y: hy + hr * 0.4), control1: CGPoint(x: hx - hr * 1.2, y: hy + hr * 0.4), control2: CGPoint(x: hx - hr * 1.2, y: hy + hr * 1.2))
                hp.addCurve(to: CGPoint(x: hx, y: hy - hr * 0.7), control1: CGPoint(x: hx + hr * 1.2, y: hy + hr * 1.2), control2: CGPoint(x: hx + hr * 1.2, y: hy + hr * 0.4))
                ctx.addPath(hp)
                ctx.fillPath()
            }

        } else if style == "holiday_garland" {
            // Holiday Pine & Bow Garland
            let topY = height - round(height * 0.04)
            ctx.setStrokeColor(red: 21/255.0, green: 128/255.0, blue: 61/255.0, alpha: 0.9)
            ctx.setLineWidth(10.0)
            ctx.beginPath()
            ctx.move(to: CGPoint(x: 10, y: topY))
            ctx.addCurve(to: CGPoint(x: width - 10, y: topY), control1: CGPoint(x: width * 0.3, y: topY - 20), control2: CGPoint(x: width * 0.7, y: topY - 20))
            ctx.strokePath()

            // Holly berries
            ctx.setFillColor(red: 220/255.0, green: 38/255.0, blue: 38/255.0, alpha: 1.0)
            var bx: CGFloat = 30
            while bx < width - 20 {
                let bt = (bx - 10) / (width - 20)
                let by = topY - 4.0 * 20.0 * bt * (1.0 - bt)
                ctx.fillEllipse(in: CGRect(x: bx - 4, y: by - 4, width: 8, height: 8))
                ctx.fillEllipse(in: CGRect(x: bx + 3, y: by - 1, width: 6, height: 6))
                bx += 50
            }

            // Big red center bow
            ctx.setFillColor(red: 185/255.0, green: 28/255.0, blue: 28/255.0, alpha: 1.0)
            ctx.fillEllipse(in: CGRect(x: width / 2.0 - 7, y: topY - 20 - 7, width: 14, height: 14))

        } else if style == "botanical_foliage" {
            // Autumn Botanical Leaves & Foliage Frame
            let leafCols: [CGColor] = [
                CGColor(srgbRed: 234/255.0, green: 88/255.0, blue: 12/255.0, alpha: 0.85),
                CGColor(srgbRed: 202/255.0, green: 138/255.0, blue: 4/255.0, alpha: 0.85),
                CGColor(srgbRed: 180/255.0, green: 83/255.0, blue: 9/255.0, alpha: 0.85),
                CGColor(srgbRed: 185/255.0, green: 28/255.0, blue: 28/255.0, alpha: 0.85)
            ]
            let margin = round(min(width, height) * 0.04)
            func drawFoliageLeaf(lx: CGFloat, ly: CGFloat, angle: CGFloat, col: CGColor) {
                ctx.saveGState()
                ctx.translateBy(x: lx, y: ly)
                ctx.rotate(by: angle)
                ctx.setFillColor(col)
                ctx.beginPath()
                ctx.move(to: .zero)
                ctx.addQuadCurve(to: CGPoint(x: 22, y: 0), control: CGPoint(x: 11, y: 9))
                ctx.addQuadCurve(to: .zero, control: CGPoint(x: 11, y: -9))
                ctx.fillPath()
                ctx.restoreGState()
            }
            var lx: CGFloat = margin + 15
            var i = 0
            while lx < width - margin {
                drawFoliageLeaf(lx: lx, ly: height - margin, angle: (i % 2 == 0 ? 0.3 : -0.3), col: leafCols[i % leafCols.count])
                drawFoliageLeaf(lx: lx, ly: margin, angle: .pi + (i % 2 == 0 ? 0.3 : -0.3), col: leafCols[(i + 1) % leafCols.count])
                lx += 32
                i += 1
            }
        }

        ctx.restoreGState()
    }

    public static func drawStickerOverlay(ctx: CGContext, width: CGFloat, height: CGFloat, options: InstaxImageOptions) {
        let hasCustom = (options.stickerImage != nil)
        let hasEmoji = (options.sticker != "none" && stickerMap[options.sticker] != nil)
        guard hasCustom || hasEmoji else { return }

        let targetDim = min(width, height) * CGFloat(options.stickerScale)
        let margin = round(min(width, height) * 0.06)

        var cx: CGFloat = width - margin - targetDim / 2.0
        var cy: CGFloat = margin + targetDim / 2.0

        if options.stickerPosition == "custom" {
            cx = width / 2.0 + CGFloat(options.stickerX) * (width / 2.0 - targetDim / 2.0)
            cy = height / 2.0 - CGFloat(options.stickerY) * (height / 2.0 - targetDim / 2.0)
        } else {
            switch options.stickerPosition {
            case "topLeft":
                cx = margin + targetDim / 2.0
                cy = height - margin - targetDim / 2.0
            case "topRight":
                cx = width - margin - targetDim / 2.0
                cy = height - margin - targetDim / 2.0
            case "bottomLeft":
                cx = margin + targetDim / 2.0
                cy = margin + targetDim / 2.0
            case "bottomRight":
                cx = width - margin - targetDim / 2.0
                cy = margin + targetDim / 2.0
            case "center":
                cx = width / 2.0
                cy = height / 2.0
            case "topCenter":
                cx = width / 2.0
                cy = height - margin - targetDim / 2.0
            case "bottomCenter":
                cx = width / 2.0
                cy = margin + targetDim / 2.0
            default:
                break
            }
        }

        ctx.saveGState()
        ctx.setAlpha(CGFloat(max(0.05, min(1.0, options.stickerOpacity))))
        ctx.translateBy(x: cx, y: cy)
        if options.stickerRotation != 0 {
            ctx.rotate(by: CGFloat(options.stickerRotation * .pi / 180.0))
        }

        if let custom = options.stickerImage, let cg = getNormalizedCGImage(from: custom) {
            let aspect = CGFloat(cg.width) / CGFloat(cg.height)
            var sw = targetDim
            var sh = targetDim
            if aspect > 1.0 {
                sh = targetDim / aspect
            } else {
                sw = targetDim * aspect
            }
            ctx.draw(cg, in: CGRect(x: -sw / 2.0, y: -sh / 2.0, width: sw, height: sh))
        } else if let emoji = stickerMap[options.sticker] {
            let fontSize = targetDim * 0.85
            let font = CTFontCreateWithName("AppleColorEmoji" as CFString, fontSize, nil)
            let attrs: [NSAttributedString.Key: Any] = [
                NSAttributedString.Key(kCTFontAttributeName as String): font
            ]
            let attrStr = NSAttributedString(string: emoji, attributes: attrs)
            let line = CTLineCreateWithAttributedString(attrStr)
            let bounds = CTLineGetBoundsWithOptions(line, [])
            ctx.textMatrix = .identity
            ctx.textPosition = CGPoint(x: -bounds.width / 2.0, y: -bounds.height / 2.0 - bounds.origin.y)
            CTLineDraw(line, ctx)
        }

        ctx.restoreGState()
    }

    public static func drawCustomBanner(ctx: CGContext, width: CGFloat, height: CGFloat, options: InstaxImageOptions) {
        let text = options.bannerText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty && options.bannerStyle != "none" else { return }

        let iconMap: [String: String] = [
            "heart": "❤️", "sparkles": "✨", "party": "🎉", "star": "⭐",
            "camera": "📸", "cake": "🎂", "flower": "🌸", "ring": "💍"
        ]
        let icon = iconMap[options.bannerIcon] ?? ""
        let fullText = icon.isEmpty ? text : "\(icon) \(text)"

        let cx = width / 2.0 + CGFloat(options.bannerX) * (width / 2.0 - 50.0)
        let cy = height / 2.0 - CGFloat(options.bannerY) * (height / 2.0 - 50.0)
        let scale = CGFloat(max(0.2, min(3.0, options.bannerScale)))

        func colorFromHex(_ hex: String, alpha: CGFloat = 1.0) -> CGColor {
            var cString = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
            if cString.hasPrefix("#") { cString.removeFirst() }
            if cString.count == 6 {
                var rgbValue: UInt64 = 0
                Scanner(string: cString).scanHexInt64(&rgbValue)
                return CGColor(srgbRed: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
                               green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
                               blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
                               alpha: alpha)
            }
            return CGColor(srgbRed: 0.88, green: 0.11, blue: 0.28, alpha: alpha)
        }

        let bgColor = colorFromHex(options.bannerBgColor)
        let textColor = colorFromHex(options.bannerTextColor)

        ctx.saveGState()
        ctx.translateBy(x: cx, y: cy)
        if options.bannerRotation != 0 {
            ctx.rotate(by: CGFloat(options.bannerRotation * .pi / 180.0))
        }
        ctx.scaleBy(x: scale, y: scale)

        let fontSize: CGFloat = 20.0
        let font = CTFontCreateWithName("HelveticaNeue-Bold" as CFString, fontSize, nil)
        let attrs: [NSAttributedString.Key: Any] = [
            NSAttributedString.Key(kCTFontAttributeName as String): font,
            NSAttributedString.Key(kCTForegroundColorAttributeName as String): textColor
        ]
        let attrStr = NSAttributedString(string: fullText, attributes: attrs)
        let line = CTLineCreateWithAttributedString(attrStr)
        let bounds = CTLineGetBoundsWithOptions(line, [])
        let tw = bounds.width
        let th = bounds.height

        if options.bannerStyle == "ribbon" {
            let rw = max(130.0, tw + 46.0)
            let rh: CGFloat = 40.0
            let tailW: CGFloat = 34.0
            let tailH: CGFloat = 34.0

            ctx.setFillColor(red: 0, green: 0, blue: 0, alpha: 0.35)
            let f1 = CGMutablePath()
            f1.move(to: CGPoint(x: -rw / 2.0, y: -rh / 2.0))
            f1.addLine(to: CGPoint(x: -rw / 2.0, y: -rh / 2.0 - 8.0))
            f1.addLine(to: CGPoint(x: -rw / 2.0 + 10.0, y: -rh / 2.0))
            f1.closeSubpath()
            ctx.addPath(f1)
            ctx.fillPath()

            let f2 = CGMutablePath()
            f2.move(to: CGPoint(x: rw / 2.0, y: -rh / 2.0))
            f2.addLine(to: CGPoint(x: rw / 2.0, y: -rh / 2.0 - 8.0))
            f2.addLine(to: CGPoint(x: rw / 2.0 - 10.0, y: -rh / 2.0))
            f2.closeSubpath()
            ctx.addPath(f2)
            ctx.fillPath()

            ctx.setFillColor(bgColor)
            let leftTail = CGMutablePath()
            leftTail.move(to: CGPoint(x: -rw / 2.0 + 4.0, y: -rh / 2.0 - 6.0))
            leftTail.addLine(to: CGPoint(x: -rw / 2.0 - tailW, y: -rh / 2.0 - 6.0))
            leftTail.addLine(to: CGPoint(x: -rw / 2.0 - tailW + 12.0, y: -rh / 2.0 - 6.0 + tailH / 2.0))
            leftTail.addLine(to: CGPoint(x: -rw / 2.0 - tailW, y: -rh / 2.0 - 6.0 + tailH))
            leftTail.addLine(to: CGPoint(x: -rw / 2.0 + 4.0, y: -rh / 2.0 - 6.0 + tailH))
            leftTail.closeSubpath()
            ctx.addPath(leftTail)
            ctx.fillPath()

            let rightTail = CGMutablePath()
            rightTail.move(to: CGPoint(x: rw / 2.0 - 4.0, y: -rh / 2.0 - 6.0))
            rightTail.addLine(to: CGPoint(x: rw / 2.0 + tailW, y: -rh / 2.0 - 6.0))
            rightTail.addLine(to: CGPoint(x: rw / 2.0 + tailW - 12.0, y: -rh / 2.0 - 6.0 + tailH / 2.0))
            rightTail.addLine(to: CGPoint(x: rw / 2.0 + tailW, y: -rh / 2.0 - 6.0 + tailH))
            rightTail.addLine(to: CGPoint(x: rw / 2.0 - 4.0, y: -rh / 2.0 - 6.0 + tailH))
            rightTail.closeSubpath()
            ctx.addPath(rightTail)
            ctx.fillPath()

            ctx.saveGState()
            ctx.setShadow(offset: CGSize(width: 0, height: -2), blur: 6.0, color: CGColor(srgbRed: 0, green: 0, blue: 0, alpha: 0.4))
            ctx.setFillColor(bgColor)
            ctx.fill(CGRect(x: -rw / 2.0, y: -rh / 2.0, width: rw, height: rh))
            ctx.restoreGState()

            ctx.setStrokeColor(red: 1, green: 1, blue: 1, alpha: 0.35)
            ctx.setLineWidth(1.2)
            ctx.stroke(CGRect(x: -rw / 2.0 + 2.0, y: -rh / 2.0 + 2.0, width: rw - 4.0, height: rh - 4.0))

            ctx.textMatrix = .identity
            ctx.textPosition = CGPoint(x: -tw / 2.0, y: -th / 2.0 + 2.0)
            CTLineDraw(line, ctx)

        } else if options.bannerStyle == "calligraphy" {
            let bw = tw + 48.0
            let bh: CGFloat = 42.0
            ctx.setFillColor(bgColor)
            let path = CGMutablePath()
            path.addRoundedRect(in: CGRect(x: -bw / 2.0, y: -bh / 2.0, width: bw, height: bh), cornerWidth: 8, cornerHeight: 8)
            ctx.addPath(path)
            ctx.fillPath()

            ctx.textMatrix = .identity
            ctx.textPosition = CGPoint(x: -tw / 2.0, y: -th / 2.0 + 2.0)
            CTLineDraw(line, ctx)

            ctx.setStrokeColor(textColor)
            ctx.setLineWidth(1.8)
            ctx.beginPath()
            ctx.move(to: CGPoint(x: -tw / 2.0, y: -th / 2.0 - 4.0))
            ctx.addQuadCurve(to: CGPoint(x: tw / 2.0, y: -th / 2.0 - 4.0), control: CGPoint(x: 0, y: -th / 2.0 - 10.0))
            ctx.strokePath()

        } else if options.bannerStyle == "pill" {
            let pw = tw + 40.0
            let ph: CGFloat = 40.0
            let path = CGPath(roundedRect: CGRect(x: -pw / 2.0, y: -ph / 2.0, width: pw, height: ph), cornerWidth: ph / 2.0, cornerHeight: ph / 2.0, transform: nil)
            ctx.setFillColor(bgColor)
            ctx.addPath(path)
            ctx.fillPath()

            ctx.setStrokeColor(red: 1, green: 1, blue: 1, alpha: 0.55)
            ctx.setLineWidth(1.5)
            ctx.addPath(path)
            ctx.strokePath()

            ctx.textMatrix = .identity
            ctx.textPosition = CGPoint(x: -tw / 2.0, y: -th / 2.0 + 2.0)
            CTLineDraw(line, ctx)

        } else if options.bannerStyle == "tag" {
            let tagW = tw + 56.0
            let tagH: CGFloat = 42.0
            let path = CGMutablePath()
            path.move(to: CGPoint(x: -tagW / 2.0 + 14.0, y: tagH / 2.0))
            path.addLine(to: CGPoint(x: tagW / 2.0 - 4.0, y: tagH / 2.0))
            path.addLine(to: CGPoint(x: tagW / 2.0 - 4.0, y: -tagH / 2.0))
            path.addLine(to: CGPoint(x: -tagW / 2.0 + 14.0, y: -tagH / 2.0))
            path.addLine(to: CGPoint(x: -tagW / 2.0, y: 0))
            path.closeSubpath()
            ctx.setFillColor(bgColor)
            ctx.addPath(path)
            ctx.fillPath()

            ctx.setFillColor(red: 217/255.0, green: 119/255.0, blue: 6/255.0, alpha: 1.0)
            ctx.fillEllipse(in: CGRect(x: -tagW / 2.0 + 6.0, y: -4.0, width: 8.0, height: 8.0))
            ctx.setFillColor(red: 30/255.0, green: 30/255.0, blue: 30/255.0, alpha: 1.0)
            ctx.fillEllipse(in: CGRect(x: -tagW / 2.0 + 8.0, y: -2.0, width: 4.0, height: 4.0))

            ctx.textMatrix = .identity
            ctx.textPosition = CGPoint(x: -tw / 2.0 + 6.0, y: -th / 2.0 + 2.0)
            CTLineDraw(line, ctx)

        } else if options.bannerStyle == "stamp" {
            let sw = tw + 44.0
            let sh: CGFloat = 42.0
            ctx.setStrokeColor(bgColor)
            ctx.setLineWidth(2.5)
            ctx.stroke(CGRect(x: -sw / 2.0, y: -sh / 2.0, width: sw, height: sh))
            ctx.setLineWidth(1.0)
            ctx.stroke(CGRect(x: -sw / 2.0 + 3.0, y: -sh / 2.0 + 3.0, width: sw - 6.0, height: sh - 6.0))

            ctx.textMatrix = .identity
            ctx.textPosition = CGPoint(x: -tw / 2.0, y: -th / 2.0 + 2.0)
            CTLineDraw(line, ctx)

        } else if options.bannerStyle == "garland" {
            let words = fullText.split(separator: " ").map { String($0) }
            let flagW = max(34.0, (tw + 20.0) / CGFloat(max(1, words.count)))
            let totalW = flagW * CGFloat(words.count)

            ctx.setStrokeColor(red: 1, green: 1, blue: 1, alpha: 0.65)
            ctx.setLineWidth(1.8)
            ctx.beginPath()
            ctx.move(to: CGPoint(x: -totalW / 2.0, y: 14.0))
            ctx.addQuadCurve(to: CGPoint(x: totalW / 2.0, y: 14.0), control: CGPoint(x: 0, y: 6.0))
            ctx.strokePath()

            for (idx, wrd) in words.enumerated() {
                let fx = -totalW / 2.0 + CGFloat(idx) * flagW + flagW / 2.0
                let t = CGFloat(idx + 1) / CGFloat(words.count + 1)
                let fy = 14.0 - 8.0 * 4.0 * t * (1.0 - t)
                let flagH: CGFloat = 34.0

                ctx.saveGState()
                ctx.translateBy(x: fx, y: fy)
                let tri = CGMutablePath()
                tri.move(to: CGPoint(x: -flagW / 2.0 + 2.0, y: 0))
                tri.addLine(to: CGPoint(x: flagW / 2.0 - 2.0, y: 0))
                tri.addLine(to: CGPoint(x: 0, y: -flagH))
                tri.closeSubpath()
                ctx.setFillColor(bgColor)
                ctx.addPath(tri)
                ctx.fillPath()

                let wAttr = NSAttributedString(string: wrd, attributes: [
                    NSAttributedString.Key(kCTFontAttributeName as String): CTFontCreateWithName("HelveticaNeue-Bold" as CFString, 11.0, nil),
                    NSAttributedString.Key(kCTForegroundColorAttributeName as String): textColor
                ])
                let wLine = CTLineCreateWithAttributedString(wAttr)
                let wBounds = CTLineGetBoundsWithOptions(wLine, [])
                ctx.textMatrix = .identity
                ctx.textPosition = CGPoint(x: -wBounds.width / 2.0, y: -flagH / 2.0)
                CTLineDraw(wLine, ctx)
                ctx.restoreGState()
            }
        }

        ctx.restoreGState()
    }

    /// Render 2 to 9 images into a collage canvas (supports Square 800x800, WIDE 1260x840, or Mini 600x800).
    public static func renderCollageSquare(
        images: [NSImage],
        layout: InstaxCollageLayout,
        targetWidth: Int = InstaxConstants.squareWidth,
        targetHeight: Int = InstaxConstants.squareHeight,
        spacing: CGFloat = 8,
        options: InstaxImageOptions = InstaxImageOptions()
    ) -> NSImage? {
        guard !images.isEmpty else { return nil }
        let dstW = CGFloat(targetWidth)
        let dstH = CGFloat(targetHeight)

        let colorSpace = CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB()
        guard let ctx = CGContext(
            data: nil,
            width: targetWidth,
            height: targetHeight,
            bitsPerComponent: 8,
            bytesPerRow: targetWidth * 4,
            space: colorSpace,
            bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
        ) else {
            return nil
        }

        // Fill background with border color
        let fallbackWhite = NSColor(srgbRed: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        let bgRGB = options.borderColor.nsColor.usingColorSpace(.sRGB) ?? fallbackWhite
        ctx.setFillColor(red: bgRGB.redComponent, green: bgRGB.greenComponent, blue: bgRGB.blueComponent, alpha: 1.0)
        ctx.fill(CGRect(x: 0, y: 0, width: dstW, height: dstH))
        ctx.interpolationQuality = .high

        let m = max(0.0, spacing) // Outer perimeter margin matches inner spacing
        var slots: [CGRect] = []

        switch layout {
        case .single:
            slots = [CGRect(x: m, y: m, width: dstW - 2 * m, height: dstH - 2 * m)]

        case .split2V:
            let w = (dstW - 2 * m - spacing) / 2.0
            let h = dstH - 2 * m
            slots = [
                CGRect(x: m, y: m, width: w, height: h),
                CGRect(x: m + w + spacing, y: m, width: w, height: h)
            ]

        case .split2H:
            let w = dstW - 2 * m
            let h = (dstH - 2 * m - spacing) / 2.0
            slots = [
                CGRect(x: m, y: m + h + spacing, width: w, height: h), // Top
                CGRect(x: m, y: m, width: w, height: h)                // Bottom
            ]

        case .split3Hero:
            let leftW = (dstW - 2 * m - spacing) / 2.0
            let rightW = leftW
            let rightH = (dstH - 2 * m - spacing) / 2.0
            slots = [
                CGRect(x: m, y: m, width: leftW, height: dstH - 2 * m),                          // Large Left
                CGRect(x: m + leftW + spacing, y: m + rightH + spacing, width: rightW, height: rightH), // Top Right
                CGRect(x: m + leftW + spacing, y: m, width: rightW, height: rightH)           // Bottom Right
            ]

        case .split3V:
            let w = (dstW - 2 * m - 2 * spacing) / 3.0
            let h = dstH - 2 * m
            slots = [
                CGRect(x: m, y: m, width: w, height: h),
                CGRect(x: m + w + spacing, y: m, width: w, height: h),
                CGRect(x: m + 2 * (w + spacing), y: m, width: w, height: h)
            ]

        case .split3H:
            let topH = (dstH - 2 * m - spacing) / 2.0
            let botH = topH
            let cellW = (dstW - 2 * m - spacing) / 2.0
            slots = [
                CGRect(x: m, y: m + botH + spacing, width: dstW - 2 * m, height: topH), // Large Top
                CGRect(x: m, y: m, width: cellW, height: botH),                          // Bottom Left
                CGRect(x: m + cellW + spacing, y: m, width: cellW, height: botH)          // Bottom Right
            ]

        case .grid4:
            let cellW = (dstW - 2 * m - spacing) / 2.0
            let cellH = (dstH - 2 * m - spacing) / 2.0
            slots = [
                CGRect(x: m, y: m + cellH + spacing, width: cellW, height: cellH),                 // Top Left
                CGRect(x: m + cellW + spacing, y: m + cellH + spacing, width: cellW, height: cellH),   // Top Right
                CGRect(x: m, y: m, width: cellW, height: cellH),                                   // Bottom Left
                CGRect(x: m + cellW + spacing, y: m, width: cellW, height: cellH)                  // Bottom Right
            ]

        case .strips4V:
            let w = (dstW - 2 * m - 3 * spacing) / 4.0
            let h = dstH - 2 * m
            for col in 0..<4 {
                slots.append(CGRect(x: m + CGFloat(col) * (w + spacing), y: m, width: w, height: h))
            }

        case .grid6:
            let cellW = (dstW - 2 * m - 2 * spacing) / 3.0
            let cellH = (dstH - 2 * m - spacing) / 2.0
            // Row 1 (Top)
            for col in 0..<3 {
                slots.append(CGRect(x: m + CGFloat(col) * (cellW + spacing), y: m + cellH + spacing, width: cellW, height: cellH))
            }
            // Row 2 (Bottom)
            for col in 0..<3 {
                slots.append(CGRect(x: m + CGFloat(col) * (cellW + spacing), y: m, width: cellW, height: cellH))
            }

        case .grid8:
            let cellW = (dstW - 2 * m - 3 * spacing) / 4.0
            let cellH = (dstH - 2 * m - spacing) / 2.0
            // Row 1 (Top)
            for col in 0..<4 {
                slots.append(CGRect(x: m + CGFloat(col) * (cellW + spacing), y: m + cellH + spacing, width: cellW, height: cellH))
            }
            // Row 2 (Bottom)
            for col in 0..<4 {
                slots.append(CGRect(x: m + CGFloat(col) * (cellW + spacing), y: m, width: cellW, height: cellH))
            }

        case .grid9:
            let cellW = (dstW - 2 * m - 2 * spacing) / 3.0
            let cellH = (dstH - 2 * m - 2 * spacing) / 3.0
            for row in (0..<3).reversed() {
                for col in 0..<3 {
                    slots.append(CGRect(x: m + CGFloat(col) * (cellW + spacing), y: m + CGFloat(row) * (cellH + spacing), width: cellW, height: cellH))
                }
            }
        }

        var slotOptions = options
        slotOptions.qrCodeContent = ""
        slotOptions.captionText = ""
        slotOptions.showDateStamp = false
        slotOptions.frameStyle = "none"
        slotOptions.sticker = "none"
        slotOptions.stickerImage = nil

        for (idx, slot) in slots.enumerated() {
            let img = images[idx % images.count]
            if let renderedSlot = renderSquareImage(from: img, targetWidth: Int(slot.width), targetHeight: Int(slot.height), options: slotOptions),
               let cg = getNormalizedCGImage(from: renderedSlot) {
                ctx.draw(cg, in: slot)
            }
        }

        // Decorative Film Borders & Frames on Collage
        drawDecorativeFrame(ctx: ctx, width: dstW, height: dstH, style: options.frameStyle)

        // Custom Banner Maker on Collage
        drawCustomBanner(ctx: ctx, width: dstW, height: dstH, options: options)

        // Sticker / Custom Image Overlay on Collage
        drawStickerOverlay(ctx: ctx, width: dstW, height: dstH, options: options)

        // Draw optional QR Code (Rich QR / Web link / Secret text / Contact) once on full collage
        let trimmedQR = options.qrCodeContent.trimmingCharacters(in: .whitespacesAndNewlines)
        if !trimmedQR.isEmpty {
            let qrSize = options.qrCodeSize.pixelSize(forTargetWidth: targetWidth)
            if let qrImage = generateQRCode(from: trimmedQR, size: qrSize) {
                let margin: CGFloat = max(18.0, dstW * 0.035)
                let qrRect: CGRect
                switch options.qrCodePosition {
                case .bottomRight:
                    qrRect = CGRect(x: dstW - qrSize - margin, y: margin, width: qrSize, height: qrSize)
                case .bottomLeft:
                    qrRect = CGRect(x: margin, y: margin, width: qrSize, height: qrSize)
                case .topRight:
                    qrRect = CGRect(x: dstW - qrSize - margin, y: dstH - qrSize - margin, width: qrSize, height: qrSize)
                case .topLeft:
                    qrRect = CGRect(x: margin, y: dstH - qrSize - margin, width: qrSize, height: qrSize)
                case .bottomCenter:
                    qrRect = CGRect(x: (dstW - qrSize) / 2.0, y: margin, width: qrSize, height: qrSize)
                }

                let badgePadding: CGFloat = 8.0
                let badgeRect = qrRect.insetBy(dx: -badgePadding, dy: -badgePadding)
                switch options.qrCodeStyle {
                case .frosted:
                    ctx.setFillColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 0.92)
                    let path = CGPath(roundedRect: badgeRect, cornerWidth: 10, cornerHeight: 10, transform: nil)
                    ctx.addPath(path)
                    ctx.fillPath()
                    ctx.setStrokeColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.2)
                    ctx.setLineWidth(1.5)
                    ctx.addPath(path)
                    ctx.strokePath()
                case .solidWhite:
                    ctx.setFillColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
                    let path = CGPath(roundedRect: badgeRect, cornerWidth: 8, cornerHeight: 8, transform: nil)
                    ctx.addPath(path)
                    ctx.fillPath()
                case .minimal:
                    ctx.setFillColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.65)
                    let path = CGPath(roundedRect: badgeRect, cornerWidth: 8, cornerHeight: 8, transform: nil)
                    ctx.addPath(path)
                    ctx.fillPath()
                }

                ctx.draw(qrImage, in: qrRect)
            }
        }

        guard let outCG = ctx.makeImage() else { return nil }
        let rep = NSBitmapImageRep(cgImage: outCG)
        rep.size = NSSize(width: targetWidth, height: targetHeight)
        let outImg = NSImage(size: NSSize(width: targetWidth, height: targetHeight))
        outImg.addRepresentation(rep)
        return outImg
    }

    /// Compress an 800x800 NSImage into a JPEG guaranteed to be <= `maxBytes` (default 60 KB).
    public static func compressToJPEG(
        _ image: NSImage,
        maxBytes: Int = InstaxConstants.maxJpegBytes
    ) -> (data: Data, quality: Double)? {
        guard let cgImage = getNormalizedCGImage(from: image) else {
            return nil
        }

        // Re-draw into a clean DeviceRGB bitmap so NSBitmapImageRep does not embed a ~4 KB ICC color profile
        let w = cgImage.width
        let h = cgImage.height
        var activeCG = cgImage
        if let ctx = CGContext(
            data: nil,
            width: w,
            height: h,
            bitsPerComponent: 8,
            bytesPerRow: w * 4,
            space: CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue
        ) {
            ctx.interpolationQuality = .high
            ctx.draw(cgImage, in: CGRect(x: 0, y: 0, width: w, height: h))
            if let stripped = ctx.makeImage() {
                activeCG = stripped
            }
        }

        let bitmapRep = NSBitmapImageRep(cgImage: activeCG)
        var bestCandidate: (data: Data, quality: Double)? = nil

        for qInt in stride(from: 94, through: 4, by: -4) {
            let quality = Double(qInt) / 100.0
            if let jpegData = bitmapRep.representation(
                using: .jpeg,
                properties: [.compressionFactor: NSNumber(value: quality), .progressive: NSNumber(value: false)]
            ) {
                if bestCandidate == nil || jpegData.count < bestCandidate!.data.count {
                    bestCandidate = (jpegData, quality)
                }
                if jpegData.count <= maxBytes {
                    InstaxLogger.log("[IMG] JPEG encoded: \(jpegData.count) bytes (quality: \(qInt)%, target budget: \(maxBytes / 1024) KB)")
                    return (jpegData, quality)
                }
            }
        }

        // If an extremely noisy / high-frequency image still exceeds maxBytes at 4% quality,
        // apply a subtle high-frequency smoothing pass (imperceptible on physical Instax film)
        let ciCtx = CIContext(options: [.useSoftwareRenderer: true])
        for blurRadius in [0.9, 1.6, 2.4] {
            let ciInput = CIImage(cgImage: activeCG).clampedToExtent()
            if let blur = CIFilter(name: "CIGaussianBlur") {
                blur.setValue(ciInput, forKey: kCIInputImageKey)
                blur.setValue(blurRadius, forKey: kCIInputRadiusKey)
                if let outCI = blur.outputImage?.cropped(to: CGRect(x: 0, y: 0, width: w, height: h)),
                   let blurredCG = ciCtx.createCGImage(outCI, from: CGRect(x: 0, y: 0, width: w, height: h)) {
                    let blurRep = NSBitmapImageRep(cgImage: blurredCG)
                    for qInt in stride(from: 70, through: 6, by: -8) {
                        let quality = Double(qInt) / 100.0
                        if let jpegData = blurRep.representation(
                            using: .jpeg,
                            properties: [.compressionFactor: NSNumber(value: quality), .progressive: NSNumber(value: false)]
                        ) {
                            if bestCandidate == nil || jpegData.count < bestCandidate!.data.count {
                                bestCandidate = (jpegData, quality)
                            }
                            if jpegData.count <= maxBytes {
                                InstaxLogger.log("[IMG] JPEG encoded (smoothed r=\(blurRadius)): \(jpegData.count) bytes (quality: \(qInt)%, target budget: \(maxBytes / 1024) KB)")
                                return (jpegData, quality)
                            }
                        }
                    }
                }
            }
        }

        if let fallback = bestCandidate {
            InstaxLogger.log("[IMG] JPEG fallback encoded: \(fallback.data.count) bytes")
            return fallback
        }
        return nil
    }
}

// MARK: - BLE Service & Print Engine

public struct DiscoveredPrinter: Identifiable, Equatable {
    public let id: String
    public let name: String
    public let rssi: Int
    public let peripheral: CBPeripheral

    public static func == (lhs: DiscoveredPrinter, rhs: DiscoveredPrinter) -> Bool {
        lhs.id == rhs.id && lhs.name == rhs.name && lhs.rssi == rhs.rssi
    }
}

public final class InstaxBLEController: NSObject, CBCentralManagerDelegate, CBPeripheralDelegate {
    private var central: CBCentralManager!
    private let queue = DispatchQueue(label: "com.instax.square.ble", qos: .userInitiated)

    public var onStateUpdate: ((CBManagerState) -> Void)?
    public var onPrintersDiscovered: (([DiscoveredPrinter]) -> Void)?
    public var onConnectionChanged: ((Bool, String?) -> Void)?
    public var onLog: ((String) -> Void)?

    private var discovered: [String: DiscoveredPrinter] = [:]
    private var connectedPeripheral: CBPeripheral?
    private var writeChar: CBCharacteristic?
    private var notifyChar: CBCharacteristic?

    private var rxBuffer = Data()
    private var pendingSID: InstaxSID?
    private var responseCont: CheckedContinuation<InstaxResponse, Error>?
    private var connectCont: CheckedContinuation<Void, Error>?
    private var stateReadyCont: CheckedContinuation<Void, Error>?

    public override init() {
        super.init()
        self.central = CBCentralManager(delegate: self, queue: queue)
    }

    private func log(_ msg: String) {
        onLog?(msg)
        InstaxLogger.log(msg)
    }

    public var isConnected: Bool {
        queue.sync {
            connectedPeripheral?.state == .connected && writeChar != nil && notifyChar != nil
        }
    }

    public var connectedName: String? {
        queue.sync {
            connectedPeripheral?.name
        }
    }

    public var mtuWriteSize: Int {
        queue.sync {
            guard let p = connectedPeripheral else { return 182 }
            return max(20, p.maximumWriteValueLength(for: .withoutResponse))
        }
    }

    // MARK: Async Bluetooth Operations

    public func waitUntilPoweredOn(timeout: TimeInterval = 6.0) async throws {
        log("Bluetooth: Checking adapter state...")
        try await withThrowingTaskGroup(of: Void.self) { group in
            group.addTask {
                try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
                    self.queue.async {
                        switch self.central.state {
                        case .poweredOn:
                            cont.resume()
                        case .unauthorized:
                            cont.resume(throwing: NSError(domain: "InstaxBLE", code: 10, userInfo: [
                                NSLocalizedDescriptionKey: "Bluetooth permission denied. Enable Bluetooth access for Terminal / Instax Printer in System Settings -> Privacy & Security -> Bluetooth."
                            ]))
                        case .poweredOff:
                            cont.resume(throwing: NSError(domain: "InstaxBLE", code: 11, userInfo: [
                                NSLocalizedDescriptionKey: "Mac Bluetooth is turned OFF."
                            ]))
                        case .unsupported:
                            cont.resume(throwing: NSError(domain: "InstaxBLE", code: 13, userInfo: [
                                NSLocalizedDescriptionKey: "Bluetooth Low Energy is unsupported or blocked in this environment."
                            ]))
                        default:
                            self.stateReadyCont = cont
                        }
                    }
                }
            }
            group.addTask {
                try await Task.sleep(nanoseconds: UInt64(timeout * 1_000_000_000))
                self.queue.async {
                    if let c = self.stateReadyCont {
                        self.stateReadyCont = nil
                        c.resume(throwing: NSError(domain: "InstaxBLE", code: 12, userInfo: [
                            NSLocalizedDescriptionKey: "Timed out waiting for Mac Bluetooth (state=\(self.central.state.rawValue))."
                        ]))
                    }
                }
                throw CancellationError()
            }
            _ = try await group.next()!
            group.cancelAll()
        }
    }

    public func scanForPrinters(duration: TimeInterval = 4.0) async throws -> [DiscoveredPrinter] {
        try await waitUntilPoweredOn()
        queue.async {
            self.discovered.removeAll()
            self.central.scanForPeripherals(
                withServices: nil,
                options: [CBCentralManagerScanOptionAllowDuplicatesKey: true]
            )
        }
        try await Task.sleep(nanoseconds: UInt64(duration * 1_000_000_000))
        return queue.sync {
            self.central.stopScan()
            return Array(self.discovered.values).sorted { $0.rssi > $1.rssi }
        }
    }

    public func startBackgroundScan() {
        queue.async {
            guard self.central.state == .poweredOn else { return }
            self.central.scanForPeripherals(
                withServices: nil,
                options: [CBCentralManagerScanOptionAllowDuplicatesKey: false]
            )
        }
    }

    public func stopBackgroundScan() {
        queue.async {
            if self.central.isScanning {
                self.central.stopScan()
            }
        }
    }

    public func connect(targetNameOrPrefix: String = InstaxConstants.defaultDeviceName, timeout: TimeInterval = 8.0) async throws {
        if isConnected { return }
        try await waitUntilPoweredOn()

        let startTime = Date()
        queue.async {
            self.central.scanForPeripherals(
                withServices: nil,
                options: [CBCentralManagerScanOptionAllowDuplicatesKey: true]
            )
        }

        var matched: DiscoveredPrinter?
        let needle = targetNameOrPrefix.uppercased().trimmingCharacters(in: .whitespacesAndNewlines)

        while Date().timeIntervalSince(startTime) < timeout {
            let list = queue.sync { Array(self.discovered.values).sorted { $0.rssi > $1.rssi } }
            if let exact = list.first(where: {
                $0.name.uppercased().hasPrefix(needle) || $0.name.uppercased().contains(needle) || $0.id.uppercased() == needle
            }) {
                matched = exact
                break
            }
            if needle.isEmpty || needle == "INSTAX" || needle == "INSTAX-" || needle == "AUTO", let anyInstax = list.first {
                matched = anyInstax
                break
            }
            try await Task.sleep(nanoseconds: 200_000_000)
        }

        queue.async { self.central.stopScan() }

        guard let target = matched else {
            let foundNames = queue.sync { self.discovered.values.map { $0.name }.joined(separator: ", ") }
            let hint = foundNames.isEmpty ? "none found" : foundNames
            throw NSError(domain: "InstaxBLE", code: 20, userInfo: [
                NSLocalizedDescriptionKey: "Could not find '\(targetNameOrPrefix)' over Bluetooth (discovered: \(hint)). Make sure your printer is powered ON and Bluetooth is turned OFF on your phone/tablet (Instax printers can only pair with one device at a time)."
            ])
        }

        try await connect(to: target.peripheral, timeout: timeout)
    }

    public func connect(to peripheral: CBPeripheral, timeout: TimeInterval = 8.0) async throws {
        try await withThrowingTaskGroup(of: Void.self) { group in
            group.addTask {
                try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
                    self.queue.async {
                        self.connectCont = cont
                        self.connectedPeripheral = peripheral
                        peripheral.delegate = self
                        self.central.connect(peripheral, options: nil)
                    }
                }
            }
            group.addTask {
                try await Task.sleep(nanoseconds: UInt64(timeout * 1_000_000_000))
                self.queue.async {
                    if let c = self.connectCont {
                        self.connectCont = nil
                        c.resume(throwing: NSError(domain: "InstaxBLE", code: 21, userInfo: [
                            NSLocalizedDescriptionKey: "Timed out connecting to \(peripheral.name ?? "printer")."
                        ]))
                    }
                }
                throw CancellationError()
            }
            _ = try await group.next()!
            group.cancelAll()
        }
    }

    public func disconnect() {
        queue.async {
            if let p = self.connectedPeripheral {
                self.central.cancelPeripheralConnection(p)
            }
            self.connectedPeripheral = nil
            self.writeChar = nil
            self.notifyChar = nil
        }
    }

    public func sendCommand(
        sid: InstaxSID,
        payload: Data = Data(),
        timeout: TimeInterval = 12.0
    ) async throws -> InstaxResponse {
        let packet = InstaxPacket.build(sid: sid, payload: payload)
        let mtu = mtuWriteSize
        let hexSample = packet.prefix(16).map { String(format: "%02X", $0) }.joined(separator: " ")
        log("[TX] -> \(sid.name) (\(packet.count)B) [\(hexSample)\(packet.count > 16 ? "..." : "")]")

        return try await withThrowingTaskGroup(of: InstaxResponse.self) { group in
            group.addTask {
                try await withCheckedThrowingContinuation { (cont: CheckedContinuation<InstaxResponse, Error>) in
                    self.queue.async {
                        guard let peripheral = self.connectedPeripheral,
                              peripheral.state == .connected,
                              let writeChar = self.writeChar else {
                            cont.resume(throwing: NSError(domain: "InstaxBLE", code: 30, userInfo: [
                                NSLocalizedDescriptionKey: "Printer is not connected."
                            ]))
                            return
                        }
                        self.rxBuffer.removeAll()
                        self.pendingSID = sid
                        self.responseCont = cont

                        // Split packet into MTU-sized fragments and write with .withoutResponse
                        // (Matches ImageRequest.sendData + BTDataService.writeData in Fujifilm's macOS driver)
                        let total = packet.count
                        var offset = 0
                        var chunkIndex = 0
                        while offset < total {
                            let end = min(offset + mtu, total)
                            let slice = packet.subdata(in: offset..<end)
                            let delayMs = chunkIndex * 6
                            self.queue.asyncAfter(deadline: .now() + .milliseconds(delayMs)) {
                                peripheral.writeValue(slice, for: writeChar, type: .withoutResponse)
                            }
                            offset = end
                            chunkIndex += 1
                        }
                    }
                }
            }
            group.addTask {
                try await Task.sleep(nanoseconds: UInt64(timeout * 1_000_000_000))
                self.queue.async {
                    if let c = self.responseCont {
                        self.responseCont = nil
                        self.pendingSID = nil
                        c.resume(throwing: NSError(domain: "InstaxBLE", code: 31, userInfo: [
                            NSLocalizedDescriptionKey: "Timed out waiting for response to SID \(sid)."
                        ]))
                    }
                }
                throw CancellationError()
            }
            let result = try await group.next()!
            group.cancelAll()
            return result
        }
    }

    // MARK: High-Level Printer Queries & Printing

    public func fetchStatus() async throws -> PrinterStatus {
        var status = PrinterStatus()
        status.deviceName = connectedName ?? InstaxConstants.defaultDeviceName
        status.identifier = queue.sync { connectedPeripheral?.identifier.uuidString ?? "" }

        // 1. Manufacturer
        if let r = try? await sendCommand(sid: .deviceInfoService, payload: Data([0x00]), timeout: 5.0),
           r.isOK, r.payload.count > 1 {
            status.manufacturer = String(data: r.payload.dropFirst(), encoding: .ascii)?
                .trimmingCharacters(in: CharacterSet.controlCharacters.union(.whitespaces)) ?? ""
        }

        // 2. Model Number
        if let r = try? await sendCommand(sid: .deviceInfoService, payload: Data([0x01]), timeout: 5.0),
           r.isOK, r.payload.count > 1 {
            status.modelNumber = String(data: r.payload.dropFirst(), encoding: .ascii)?
                .trimmingCharacters(in: CharacterSet.controlCharacters.union(.whitespaces)) ?? ""
        }

        // 3. Firmware Revision
        if let r = try? await sendCommand(sid: .deviceInfoService, payload: Data([0x04]), timeout: 5.0),
           r.isOK, r.payload.count > 1 {
            status.firmwareVersion = String(data: r.payload.dropFirst(), encoding: .ascii)?
                .trimmingCharacters(in: CharacterSet.controlCharacters.union(.whitespaces)) ?? ""
        }

        // 4. Image Support Info (0x00)
        let imgInfo = try await sendCommand(sid: .supportFunctionInfo, payload: Data([0x00]), timeout: 6.0)
        if imgInfo.isOK && imgInfo.payload.count >= 7 {
            let b = [UInt8](imgInfo.payload)
            let w = (Int(b[1]) << 8) | Int(b[2])
            let h = (Int(b[3]) << 8) | Int(b[4])
            if w > 0 && h > 0 {
                status.width = w
                status.height = h
            }
            let pktSz = (Int(b[5]) << 8) | Int(b[6])
            if pktSz >= 128 && pktSz <= 4096 {
                status.chunkSize = pktSz
            }
            let picOpt = b[6]
            status.supports3DLut = ((picOpt >> 3) & 0x01) == 1
            if b.count >= 11 {
                let maxJpeg = (Int(b[7]) << 24) | (Int(b[8]) << 16) | (Int(b[9]) << 8) | Int(b[10])
                if maxJpeg >= 10_000 && maxJpeg <= 500_000 {
                    status.maxJpegSize = maxJpeg
                }
            }
        }

        // 5. Battery Info (0x01) - exact bit layout from InstaxPrinterInfo.updateBatteryInfo (0x100052594)
        let battInfo = try await sendCommand(sid: .supportFunctionInfo, payload: Data([0x01]), timeout: 6.0)
        if battInfo.isOK && battInfo.payload.count >= 2 {
            let b = [UInt8](battInfo.payload)
            status.batteryLevel = min(4, Int(b[1] & 0x07))
            status.isCharging = ((b[1] >> 3) & 0x01) == 1
            if b.count >= 3 {
                let pct = Int(b[2])
                status.batteryPercent = pct > 94 ? 100 : pct
            }
        }

        // 6. Printer Function Info (0x02) - exact bit layout from InstaxPrinterInfo.updatePrinterInfo (0x1000522c0)
        let prtInfo = try await sendCommand(sid: .supportFunctionInfo, payload: Data([0x02]), timeout: 6.0)
        if prtInfo.isOK && prtInfo.payload.count >= 2 {
            let b = [UInt8](prtInfo.payload)
            status.filmRemaining = Int(b[1] & 0x0F)
            if b.count >= 3 {
                status.isCoverOpen = (b[2] & 0x01) == 1
                status.isBusy = ((b[2] >> 1) & 0x01) == 1
                status.hasError = ((b[2] >> 2) & 0x01) == 1
            }
            if b.count >= 4 {
                status.resultPrintRequest = b[3]
            }
            if b.count >= 5 {
                status.waitSeconds = Int(b[4]) + 3
            }
            if b.count >= 9 {
                status.printerErrorType = UInt32(b[5]) | (UInt32(b[6]) << 8) | (UInt32(b[7]) << 16) | (UInt32(b[8]) << 24)
            }
        }

        // 7. Print History Info (0x03)
        if let histInfo = try? await sendCommand(sid: .supportFunctionInfo, payload: Data([0x03]), timeout: 5.0),
           histInfo.isOK && histInfo.payload.count >= 5 {
            let b = [UInt8](histInfo.payload)
            status.totalPrints = (Int(b[1]) << 24) | (Int(b[2]) << 16) | (Int(b[3]) << 8) | Int(b[4])
        }

        log("[STATUS] Hardware Status: \(status.deviceName) — Battery: \(status.batteryPercent)% (Lvl \(status.batteryLevel), \(status.isCharging ? "Charging" : "Discharging")), Film: \(status.filmRemaining)/10, Res: \(status.width)×\(status.height), MaxJPEG: \(status.maxJpegSize)B, Chunk: \(status.chunkSize)B, 3D-LUT: \(status.supports3DLut), Cover: \(status.isCoverOpen ? "OPEN" : "Closed"), Error: \(status.hasError ? status.printerErrorDescription : "None")")


        return status
    }

    /// Play a single brief rainbow flash on the front LED and automatically restore normal status LED.
    /// Layout for LED_PATTERN_SETTINGS (48, 1):
    /// `[when (0x00 = now), color_count, speed, repeat (0x00 = play once, 0xFF = loop forever), (B, G, R) * color_count]`
    public func flashRainbowLED() async throws {
        let payload = Data([
            0x00, // when = 0 (now)
            0x06, // color_count = 6
            0x0F, // speed = 15 (~150ms per step)
            0x00, // repeat = 0 (play ONCE — do NOT loop!)
            0x00, 0x00, 0xFF, // Red (BGR)
            0x00, 0x7F, 0xFF, // Orange (BGR)
            0x00, 0xFF, 0xFF, // Yellow (BGR)
            0x00, 0xFF, 0x00, // Green (BGR)
            0xFF, 0x00, 0x00, // Blue (BGR)
            0xFF, 0x00, 0x8B  // Violet (BGR)
        ])
        _ = try await sendCommand(sid: .ledPatternSettings, payload: payload, timeout: 5.0)
        try? await Task.sleep(nanoseconds: 1_400_000_000)
        try? await stopLED()
    }

    /// Immediately stop any looping LED pattern and restore normal status LED behavior.
    public func stopLED() async throws {
        // Send 1 frame of [B=0, G=0, R=0] with repeat = 0 (play once) to stop any active LED loop
        let stopPayload = Data([
            0x00, // when = 0 (now)
            0x01, // color_count = 1
            0x05, // speed = 5
            0x00, // repeat = 0 (play once & clear)
            0x00, 0x00, 0x00 // Black/Off (BGR)
        ])
        _ = try await sendCommand(sid: .ledPatternSettings, payload: stopPayload, timeout: 5.0)
    }

    /// Sends REJECT_FILM_COVER (SID 16, 129) to eject the protective black plastic sheet from a newly loaded film pack.
    public func ejectFilmCover() async throws {
        log("[PRINTER] Sending REJECT_FILM_COVER hardware command (SID 16, 129)...")
        let resp = try await sendCommand(sid: .rejectFilmCover, payload: Data(), timeout: 15.0)
        guard resp.isOK else {
            log("[ERR] REJECT_FILM_COVER rejected: \(resp.resultDescription)")
            throw NSError(domain: "InstaxPrint", code: 47, userInfo: [
                NSLocalizedDescriptionKey: "Failed to eject film cover: \(resp.resultDescription)"
            ])
        }
        log("[PRINTER] REJECT_FILM_COVER command accepted. Waiting 8s for motor to cycle dark slide...")
        try await Task.sleep(nanoseconds: 8_000_000_000)
        let st = try await fetchStatus()
        log("[PRINTER] Film cover ejection cycle complete. Status: Film \(st.filmRemaining)/10, Error: \(st.hasError ? st.printerErrorDescription : "None")")
    }


    public func printJPEG(
        _ jpegData: Data,
        mode: InstaxPrintMode = .none,
        dryRun: Bool = false,
        progress: ((String, Double) -> Void)? = nil
    ) async throws -> PrinterStatus {
        progress?("Checking printer status...", 0.03)
        let status = try await fetchStatus()

        if status.isCoverOpen {
            throw NSError(domain: "InstaxPrint", code: 40, userInfo: [
                NSLocalizedDescriptionKey: "Printer film door is open. Please close the back cover."
            ])
        }
        if !dryRun && status.filmRemaining <= 0 {
            throw NSError(domain: "InstaxPrint", code: 41, userInfo: [
                NSLocalizedDescriptionKey: "No film remaining (0/10) in printer."
            ])
        }
        if dryRun && status.filmRemaining <= 0 {
            log("[DRY-RUN] Film count is 0/10. Dry run mode active: testing full data transmission without film.")
        }
        if status.batteryPercent < 6 && status.batteryLevel == 0 && !status.isCharging {
            throw NSError(domain: "InstaxPrint", code: 42, userInfo: [
                NSLocalizedDescriptionKey: "Battery is too low (\(status.batteryPercent)%) to print."
            ])
        }

        let totalBytes = jpegData.count
        let optionByte: UInt8 = (mode == .natural && status.supports3DLut) ? 0x08 : 0x00
        var frameSize = status.chunkSize > 0 ? status.chunkSize : InstaxConstants.defaultChunkSize

        progress?("Starting image download (\(totalBytes / 1024) KB)...", 0.06)
        let totalSizeU32 = UInt32(totalBytes)
        var startPayload = Data([0x02, optionByte, 0x00, 0x00])
        startPayload.append(UInt8((totalSizeU32 >> 24) & 0xFF))
        startPayload.append(UInt8((totalSizeU32 >> 16) & 0xFF))
        startPayload.append(UInt8((totalSizeU32 >> 8) & 0xFF))
        startPayload.append(UInt8(totalSizeU32 & 0xFF))

        let startResp = try await sendCommand(sid: .printImageDownloadStart, payload: startPayload, timeout: 12.0)
        guard startResp.isOK else {
            throw NSError(domain: "InstaxPrint", code: 43, userInfo: [
                NSLocalizedDescriptionKey: "PRINT_IMAGE_DOWNLOAD_START rejected: \(startResp.resultDescription)"
            ])
        }

        // Read printer's preferred packetLength from response payload[0..<4] if present
        if startResp.payload.count >= 4 {
            let b = [UInt8](startResp.payload)
            let reported = (Int(b[0]) << 24) | (Int(b[1]) << 16) | (Int(b[2]) << 8) | Int(b[3])
            if reported >= 128 && reported <= 4096 {
                frameSize = reported
            }
        }

        let totalFrames = (totalBytes + frameSize - 1) / frameSize
        let runKind = dryRun ? " [DRY-RUN]" : ""
        log("[PRINT]\(runKind) Image download start: \(totalBytes)B JPEG raw (declared size: \(totalBytes)B, \(totalFrames) chunks @ \(frameSize)B fixed BLE frame, mode: \(mode.rawValue))")
        do {
            for seq in 0..<totalFrames {
                let startIdx = seq * frameSize
                let endIdx = min(startIdx + frameSize, totalBytes)
                var chunk = jpegData.subdata(in: startIdx..<endIdx)

                // The printer BLE receiver requires every PRINT_IMAGE_DOWNLOAD_DATA packet
                // to match the negotiated frameSize (900B payload = 911B packet).
                // Trailing zeroes on the last chunk are ignored by the printer's JPEG decoder
                // because DOWNLOAD_START already set the exact unpadded byte size.
                if chunk.count < frameSize {
                    chunk.append(Data(repeating: 0, count: frameSize - chunk.count))
                }

                let seqU32 = UInt32(seq)
                var dataPayload = Data(capacity: 4 + frameSize)
                dataPayload.append(UInt8((seqU32 >> 24) & 0xFF))
                dataPayload.append(UInt8((seqU32 >> 16) & 0xFF))
                dataPayload.append(UInt8((seqU32 >> 8) & 0xFF))
                dataPayload.append(UInt8(seqU32 & 0xFF))
                dataPayload.append(chunk)

                let pct = 0.08 + (Double(seq + 1) / Double(totalFrames)) * 0.76
                let dryTag = dryRun ? "[Dry Run] " : ""
                progress?("\(dryTag)Uploading packet \(seq + 1)/\(totalFrames)...", pct)

                let dataResp = try await sendCommand(sid: .printImageDownloadData, payload: dataPayload, timeout: 15.0)
                guard dataResp.isOK else {
                    log("[ERR] Chunk \(seq + 1)/\(totalFrames) failed: \(dataResp.resultDescription)")
                    throw NSError(domain: "InstaxPrint", code: 44, userInfo: [
                        NSLocalizedDescriptionKey: "Packet \(seq + 1)/\(totalFrames) rejected: \(dataResp.resultDescription)"
                    ])
                }
                if seq == 0 || seq == totalFrames - 1 || (seq + 1) % 10 == 0 {
                    log("[PRINT]\(runKind) Upload chunk \(seq + 1)/\(totalFrames) (\(chunk.count)B) confirmed OK")
                }
            }
        } catch {
            log("[ERR] Print transmission aborted: \(error.localizedDescription)")
            _ = try? await sendCommand(sid: .printImageDownloadCancel, payload: Data(), timeout: 3.0)
            throw error
        }

        progress?("Finalizing image transfer...", 0.87)
        let endResp = try await sendCommand(sid: .printImageDownloadEnd, payload: Data(), timeout: 10.0)
        guard endResp.isOK else {
            log("[ERR] PRINT_IMAGE_DOWNLOAD_END rejected: \(endResp.resultDescription)")
            throw NSError(domain: "InstaxPrint", code: 45, userInfo: [
                NSLocalizedDescriptionKey: "PRINT_IMAGE_DOWNLOAD_END rejected: \(endResp.resultDescription)"
            ])
        }

        // Brief delay for firmware image buffer validation
        try? await Task.sleep(nanoseconds: 300_000_000)

        if let stCheck = try? await fetchStatus(), stCheck.hasError && !status.hasError {
            log("[WARN] Printer reported status flag after download: \(stCheck.printerErrorDescription)")
        }

        if dryRun {
            log("[DRY-RUN] ✅ Test run complete! All \(totalFrames) chunks received and verified by printer ASIC in RAM.")
            log("[DRY-RUN] Releasing image buffer via PRINT_IMAGE_DOWNLOAD_CANCEL (0 film used).")
            progress?("Dry run verified! 100% data delivered. (0 film used)", 1.0)
            _ = try? await sendCommand(sid: .printImageDownloadCancel, payload: Data(), timeout: 4.0)
            try? await Task.sleep(nanoseconds: 500_000_000)
            let finalStatus = (try? await fetchStatus()) ?? status
            log("[DRY-RUN] Printer idle status confirmed. Film count: \(finalStatus.filmRemaining)/10.")
            return finalStatus
        }

        progress?("Triggering physical print...", 0.92)
        log("[PRINT] Firing PRINT_IMAGE hardware command...")
        let prtResp = try await sendCommand(sid: .printImage, payload: Data(), timeout: 15.0)
        guard prtResp.isOK else {
            log("[ERR] PRINT_IMAGE failed: \(prtResp.resultDescription)")
            throw NSError(domain: "InstaxPrint", code: 46, userInfo: [
                NSLocalizedDescriptionKey: "PRINT_IMAGE failed: \(prtResp.resultDescription)"
            ])
        }

        var waitSecs = status.waitSeconds
        if let firstByte = prtResp.payload.first, firstByte > 0 {
            waitSecs = Int(firstByte) + 3
        }

        let printerKind = status.width == 1260 ? "Instax WIDE" : (status.width == 600 ? "Instax Mini" : "Instax SQUARE")
        log("[PRINT] Hardware print in progress. Ejecting film, pausing for \(waitSecs)s...")
        progress?("Ejecting \(printerKind) film (\(waitSecs)s)...", 0.96)
        try await Task.sleep(nanoseconds: UInt64(max(waitSecs, 15)) * 1_000_000_000)

        // Poll printer status to confirm print completed
        var updatedStatus = status
        for _ in 0..<3 {
            if let st = try? await fetchStatus() {
                updatedStatus = st
                if !st.isBusy { break }
            }
            try await Task.sleep(nanoseconds: 2_000_000_000)
        }

        if updatedStatus.resultPrintRequest == 0xF0 && updatedStatus.filmRemaining == status.filmRemaining {
            log("[ERR] Hardware error after print: \(updatedStatus.printerErrorDescription)")
            throw NSError(domain: "InstaxPrint", code: 50, userInfo: [
                NSLocalizedDescriptionKey: "Print failed: \(updatedStatus.printerErrorDescription)"
            ])
        }

        log("[PRINT] Print successful! Remaining film: \(updatedStatus.filmRemaining)/10")
        progress?("Print complete! (\(updatedStatus.filmRemaining)/10 film remaining)", 1.0)
        return updatedStatus
    }


    // MARK: CBCentralManagerDelegate & CBPeripheralDelegate

    public func centralManagerDidUpdateState(_ central: CBCentralManager) {
        onStateUpdate?(central.state)
        if central.state == .poweredOn, let c = stateReadyCont {
            stateReadyCont = nil
            c.resume()
        } else if central.state == .unauthorized, let c = stateReadyCont {
            stateReadyCont = nil
            c.resume(throwing: NSError(domain: "InstaxBLE", code: 10, userInfo: [
                NSLocalizedDescriptionKey: "Bluetooth permission denied. Enable Bluetooth access in System Settings -> Privacy & Security -> Bluetooth."
            ]))
        } else if central.state == .poweredOff, let c = stateReadyCont {
            stateReadyCont = nil
            c.resume(throwing: NSError(domain: "InstaxBLE", code: 11, userInfo: [
                NSLocalizedDescriptionKey: "Mac Bluetooth is powered off."
            ]))
        } else if central.state == .unsupported, let c = stateReadyCont {
            stateReadyCont = nil
            c.resume(throwing: NSError(domain: "InstaxBLE", code: 13, userInfo: [
                NSLocalizedDescriptionKey: "Bluetooth Low Energy is unsupported or blocked in this environment."
            ]))
        }
    }

    public func centralManager(
        _ central: CBCentralManager,
        didDiscover peripheral: CBPeripheral,
        advertisementData: [String: Any],
        rssi RSSI: NSNumber
    ) {
        let localName = (advertisementData[CBAdvertisementDataLocalNameKey] as? String) ?? peripheral.name ?? ""
        let serviceUUIDs = (advertisementData[CBAdvertisementDataServiceUUIDsKey] as? [CBUUID]) ?? []
        let isInstax = localName.uppercased().hasPrefix("INSTAX") || serviceUUIDs.contains(InstaxConstants.serviceUUID)

        guard isInstax else { return }
        let displayName = localName.isEmpty ? (peripheral.name ?? "INSTAX Printer") : localName
        let item = DiscoveredPrinter(
            id: peripheral.identifier.uuidString,
            name: displayName,
            rssi: RSSI.intValue,
            peripheral: peripheral
        )
        discovered[item.id] = item
        let list = Array(discovered.values).sorted { $0.rssi > $1.rssi }
        onPrintersDiscovered?(list)
    }

    public func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        log("Connected to \(peripheral.name ?? "printer"), discovering GATT services...")
        peripheral.discoverServices([InstaxConstants.serviceUUID])
    }

    public func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        if let c = connectCont {
            connectCont = nil
            c.resume(throwing: error ?? NSError(domain: "InstaxBLE", code: 22, userInfo: [
                NSLocalizedDescriptionKey: "Failed to connect to printer."
            ]))
        }
        onConnectionChanged?(false, nil)
    }

    public func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        writeChar = nil
        notifyChar = nil
        if let c = responseCont {
            responseCont = nil
            pendingSID = nil
            c.resume(throwing: NSError(domain: "InstaxBLE", code: 23, userInfo: [
                NSLocalizedDescriptionKey: "Printer disconnected unexpectedly."
            ]))
        }
        onConnectionChanged?(false, nil)
    }

    public func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        if let error = error {
            if let c = connectCont {
                connectCont = nil
                c.resume(throwing: error)
            }
            return
        }
        guard let services = peripheral.services else { return }
        for svc in services where svc.uuid == InstaxConstants.serviceUUID {
            peripheral.discoverCharacteristics(
                [InstaxConstants.writeCharUUID, InstaxConstants.notifyCharUUID],
                for: svc
            )
        }
    }

    public func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        if let error = error {
            if let c = connectCont {
                connectCont = nil
                c.resume(throwing: error)
            }
            return
        }
        guard let chars = service.characteristics else { return }
        for ch in chars {
            if ch.uuid == InstaxConstants.writeCharUUID {
                writeChar = ch
            } else if ch.uuid == InstaxConstants.notifyCharUUID {
                notifyChar = ch
                peripheral.setNotifyValue(true, for: ch)
            }
        }
    }

    public func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        if let error = error {
            if let c = connectCont {
                connectCont = nil
                c.resume(throwing: error)
            }
            return
        }
        if characteristic.uuid == InstaxConstants.notifyCharUUID && writeChar != nil {
            if let c = connectCont {
                connectCont = nil
                c.resume()
            }
            onConnectionChanged?(true, peripheral.name ?? InstaxConstants.defaultDeviceName)
        }
    }

    public func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        guard characteristic.uuid == InstaxConstants.notifyCharUUID,
              let value = characteristic.value else { return }

        rxBuffer.append(value)

        while rxBuffer.count >= 4 {
            let b = [UInt8](rxBuffer)
            if b[0] != 0x61 || b[1] != 0x42 {
                // Re-sync to 'aB' header
                if let idx = rxBuffer.range(of: Data([0x61, 0x42]))?.lowerBound {
                    rxBuffer.removeSubrange(0..<idx)
                    if rxBuffer.count < 4 { return }
                } else {
                    rxBuffer.removeAll()
                    return
                }
            }
            let hdr = [UInt8](rxBuffer.prefix(4))
            let pktSize = (Int(hdr[2]) << 8) | Int(hdr[3])
            if pktSize < 8 || pktSize > 4096 {
                rxBuffer.removeFirst(2)
                continue
            }
            if rxBuffer.count < pktSize {
                return
            }
            let rawPkt = rxBuffer.subdata(in: 0..<pktSize)
            rxBuffer.removeSubrange(0..<pktSize)

            if let resp = try? InstaxPacket.parse(rawPkt) {
                let payloadSample = resp.payload.prefix(16).map { String(format: "%02X", $0) }.joined(separator: " ")
                log("[RX] <- \(resp.sid.name) [Code: 0x\(String(format: "%02X", resp.resultCode))] (\(resp.payload.count)B) [\(payloadSample)\(resp.payload.count > 16 ? "..." : "")]")
                if let expected = pendingSID, resp.sid == expected, let cont = responseCont {
                    pendingSID = nil
                    responseCont = nil
                    cont.resume(returning: resp)
                }
            }
        }
    }
}
